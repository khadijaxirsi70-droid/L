package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.security.DecryptionOutcome
import com.example.security.EncryptionOutcome
import com.example.security.QuantumVaultCryptoEngine
import java.io.File
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app name matches Pride Shield`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Pride Shield", appName)
  }

  @Test
  fun `quantum aes256 encrypts decrypts and wipes ram key`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = QuantumVaultCryptoEngine(context)
    val secretMessage = "PRIDE_SHIELD_2028_QUANTUM_SECRET"
    val passphrase = charArrayOf('2', '0', '2', '8')

    val encOutcome =
      engine.encryptAndWipeKey(
        fileName = "top_secret.txt",
        rawPayload = secretMessage.toByteArray(Charsets.UTF_8),
        passphraseChars = passphrase,
        simulateCipherFault = false,
      )

    // Verify passphrase char array was wiped to zero in RAM
    assertTrue(passphrase.all { it == '\u0000' })
    assertTrue(encOutcome is EncryptionOutcome.EncryptedSuccess)

    val success = encOutcome as EncryptionOutcome.EncryptedSuccess
    assertTrue(success.ramWipeReport.bytesZeroized >= 64)
    assertTrue(File(success.storedPath).exists())

    val decOutcome =
      engine.decryptVaultFile(
        storedPath = success.storedPath,
        ivHex = success.ivHex,
        saltHex = success.saltHex,
        mimeType = "text/plain",
        passphraseChars = charArrayOf('2', '0', '2', '8'),
      )

    assertTrue(decOutcome is DecryptionOutcome.DecryptedSuccess)
    val dec = decOutcome as DecryptionOutcome.DecryptedSuccess
    assertEquals(secretMessage, dec.previewText)
  }

  @Test
  fun `encryption failure isolates file into quarantine sandbox`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = QuantumVaultCryptoEngine(context)
    val payload = "CRITICAL_ASSET_NEEDS_ISOLATION".toByteArray(Charsets.UTF_8)

    val outcome =
      engine.encryptAndWipeKey(
        fileName = "quarantine_test.dat",
        rawPayload = payload,
        passphraseChars = charArrayOf('2', '0', '2', '8'),
        simulateCipherFault = true,
      )

    assertTrue(outcome is EncryptionOutcome.QuarantinedInSandbox)
    val quarantined = outcome as EncryptionOutcome.QuarantinedInSandbox
    assertTrue(File(quarantined.isolatedPath).exists())
  }
}
