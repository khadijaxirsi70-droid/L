package com.example

import com.example.data.preferences.SecurityPreferencesRepository
import com.example.security.CalcEvaluationResult
import com.example.security.CamouflageCalculatorEngine
import com.example.security.DecryptionOutcome
import com.example.security.EncryptionOutcome
import com.example.security.QuantumVaultCryptoEngine
import java.io.File
import java.nio.file.Files
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun `camouflage calculator evaluates arithmetic accurately`() {
    val res = CamouflageCalculatorEngine.evaluateExpression("1000+1028")
    assertTrue(res is CalcEvaluationResult.Success)
    assertEquals("2028", (res as CalcEvaluationResult.Success).formattedValue)
  }

  @Test
  fun `camouflage calculator handles division by zero gracefully`() {
    val res = CamouflageCalculatorEngine.evaluateExpression("42÷0")
    assertTrue(res is CalcEvaluationResult.Error)
  }

  @Test
  fun `salted sha256 secret code hashing is deterministic and distinct`() {
    val hash2028 = SecurityPreferencesRepository.sha256Salted("2028")
    val hash9999 = SecurityPreferencesRepository.sha256Salted("9999")
    assertEquals(hash2028, SecurityPreferencesRepository.sha256Salted(" 2028 "))
    assertNotEquals(hash2028, hash9999)
  }

  @Test
  fun `quantum aes256 encrypts decrypts and wipes ram key material`() = runBlocking {
    val tempRoot = Files.createTempDirectory("pride_shield_vault_test").toFile()
    try {
      val engine = QuantumVaultCryptoEngine(tempRoot)
      val secretMessage = "PRIDE_SHIELD_2028_QUANTUM_AES256_VERIFIED"
      val passphrase = charArrayOf('2', '0', '2', '8')

      val encOutcome =
        engine.encryptAndWipeKey(
          fileName = "classified_intel.txt",
          rawPayload = secretMessage.toByteArray(Charsets.UTF_8),
          passphraseChars = passphrase,
          simulateCipherFault = false,
        )

      // Confirm passphrase characters were zeroized in RAM
      assertTrue(passphrase.all { it == '\u0000' })
      assertTrue(encOutcome is EncryptionOutcome.EncryptedSuccess)

      val encrypted = encOutcome as EncryptionOutcome.EncryptedSuccess
      assertTrue(encrypted.ramWipeReport.bytesZeroized >= 64)
      assertTrue(File(encrypted.storedPath).exists())

      val decOutcome =
        engine.decryptVaultFile(
          storedPath = encrypted.storedPath,
          ivHex = encrypted.ivHex,
          saltHex = encrypted.saltHex,
          mimeType = "text/plain",
          passphraseChars = charArrayOf('2', '0', '2', '8'),
        )

      assertTrue(decOutcome is DecryptionOutcome.DecryptedSuccess)
      assertEquals(secretMessage, (decOutcome as DecryptionOutcome.DecryptedSuccess).previewText)
    } finally {
      tempRoot.deleteRecursively()
    }
  }

  @Test
  fun `cipher fault automatically isolates file in quarantine and supports retry`() = runBlocking {
    val tempRoot = Files.createTempDirectory("pride_shield_quarantine_test").toFile()
    try {
      val engine = QuantumVaultCryptoEngine(tempRoot)
      val rawText = "SENSITIVE_FILE_SAVED_IN_QUARANTINE"

      val faultOutcome =
        engine.encryptAndWipeKey(
          fileName = "emergency_doc.txt",
          rawPayload = rawText.toByteArray(Charsets.UTF_8),
          passphraseChars = charArrayOf('2', '0', '2', '8'),
          simulateCipherFault = true,
        )

      assertTrue(faultOutcome is EncryptionOutcome.QuarantinedInSandbox)
      val quarantined = faultOutcome as EncryptionOutcome.QuarantinedInSandbox
      assertTrue(File(quarantined.isolatedPath).exists())

      // Now retry encryption from quarantine
      val retryOutcome =
        engine.retryEncryptFromQuarantine(
          quarantinePath = quarantined.isolatedPath,
          originalName = "emergency_doc.txt",
          passphraseChars = charArrayOf('2', '0', '2', '8'),
        )
      assertTrue(retryOutcome is EncryptionOutcome.EncryptedSuccess)
    } finally {
      tempRoot.deleteRecursively()
    }
  }
}
