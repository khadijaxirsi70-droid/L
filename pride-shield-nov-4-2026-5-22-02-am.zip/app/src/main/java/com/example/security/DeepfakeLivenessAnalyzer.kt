package com.example.security

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import kotlin.math.abs
import kotlin.math.sqrt

data class LivenessTelemetry(
  val stageIndex: Int, // 1..3
  val progressPercent: Int, // 0..100
  val instructionArabic: String,
  val opticalLuminance: Int,
  val temporalMotionScore: Float,
  val parallaxAsymmetryScore: Float,
  val isSpoofSuspected: Boolean,
  val spoofWarningArabic: String = "",
  val isVerifiedLive: Boolean = false,
)

/**
 * Real-time CameraX YUV_420_888 Anti-Deepfake Liveness Frame Analyzer.
 *
 * Defeats static 2D photographs and frozen screens by requiring:
 * 1. Valid dynamic optical luminance & contrast range in the central facial region.
 * 2. Multi-frame temporal pixel flux (proving non-frozen organic motion).
 * 3. Regional Left-vs-Right 3D parallax differential shift during head movement challenge.
 */
class DeepfakeLivenessAnalyzer(
  private val onTelemetryUpdate: (LivenessTelemetry) -> Unit,
  private val onLivenessVerified: () -> Unit,
  private val onAnalyzerError: (String) -> Unit,
) : ImageAnalysis.Analyzer {

  private var previousSampleGrid: IntArray? = null
  private var consecutiveValidOpticalFrames = 0
  private var accumulatedParallaxHits = 0
  private var accumulatedOrganicEntropyHits = 0
  private var frozenFrameCounter = 0
  private var completed = false
  private var lastEmitTimeMs = 0L

  override fun analyze(image: ImageProxy) {
    try {
      if (completed) return

      val planes = image.planes
      if (planes.isEmpty()) return

      val yBuffer = planes[0].buffer
      val rowStride = planes[0].rowStride
      val pixelStride = planes[0].pixelStride
      val width = image.width
      val height = image.height

      if (width < 32 || height < 32) return

      // Sample a 12x12 grid in the central 60% biometric ROI
      val gridSize = 12
      val currentGrid = IntArray(gridSize * gridSize)
      val startX = (width * 0.2f).toInt()
      val endX = (width * 0.8f).toInt()
      val startY = (height * 0.2f).toInt()
      val endY = (height * 0.8f).toInt()
      val stepX = ((endX - startX) / gridSize).coerceAtLeast(1)
      val stepY = ((endY - startY) / gridSize).coerceAtLeast(1)

      var sumLuma = 0L
      var sumSqLuma = 0L
      var idx = 0

      for (gy in 0 until gridSize) {
        val py = (startY + gy * stepY).coerceIn(0, height - 1)
        for (gx in 0 until gridSize) {
          val px = (startX + gx * stepX).coerceIn(0, width - 1)
          val bufferIndex = py * rowStride + px * pixelStride
          val luma =
            if (bufferIndex in 0 until yBuffer.limit()) {
              yBuffer.get(bufferIndex).toInt() and 0xFF
            } else {
              0
            }
          currentGrid[idx++] = luma
          sumLuma += luma
          sumSqLuma += (luma * luma)
        }
      }

      val totalSamples = currentGrid.size
      val meanLuma = (sumLuma / totalSamples).toInt()
      val variance =
        ((sumSqLuma.toDouble() / totalSamples) - (meanLuma.toDouble() * meanLuma.toDouble()))
          .coerceAtLeast(0.0)
      val contrastStdDev = sqrt(variance).toFloat()

      var temporalDiffSum = 0f
      var leftZoneDelta = 0f
      var rightZoneDelta = 0f

      val prev = previousSampleGrid
      if (prev != null && prev.size == currentGrid.size) {
        for (gy in 0 until gridSize) {
          for (gx in 0 until gridSize) {
            val cell = gy * gridSize + gx
            val delta = abs(currentGrid[cell] - prev[cell]).toFloat()
            temporalDiffSum += delta
            if (gx < gridSize / 2) {
              leftZoneDelta += delta
            } else {
              rightZoneDelta += delta
            }
          }
        }
      }
      previousSampleGrid = currentGrid

      val meanTemporalMotion =
        if (prev != null) temporalDiffSum / totalSamples.toFloat() else 0f
      val parallaxAsymmetry =
        if (prev != null) abs(leftZoneDelta - rightZoneDelta) / (totalSamples / 2f) else 0f

      // Evaluate Optical Quality
      val hasGoodLighting = meanLuma in 24..238 && contrastStdDev >= 11f
      if (!hasGoodLighting) {
        val now = System.currentTimeMillis()
        if (now - lastEmitTimeMs > 140L) {
          lastEmitTimeMs = now
          onTelemetryUpdate(
            LivenessTelemetry(
              stageIndex = 1,
              progressPercent = 12,
              instructionArabic =
                if (meanLuma < 24) "الإضاءة منخفضة جداً — وجّه الكاميرا نحو وجهك في مكان مضاء"
                else "ضع وجهك داخل الإطار الحيوي لإثبات الحضور البصري",
              opticalLuminance = meanLuma,
              temporalMotionScore = meanTemporalMotion,
              parallaxAsymmetryScore = parallaxAsymmetry,
              isSpoofSuspected = false,
            )
          )
        }
        return
      }

      consecutiveValidOpticalFrames++

      // Anti-Photo / Frozen Frame Spoof Check
      if (prev != null && meanTemporalMotion < 0.55f) {
        frozenFrameCounter++
      } else {
        frozenFrameCounter = (frozenFrameCounter - 2).coerceAtLeast(0)
      }

      val isStaticSpoofSuspected = frozenFrameCounter >= 18

      // Accumulate 3D Parallax & Organic Micro-Movement hits
      if (meanTemporalMotion in 1.2f..42.0f && parallaxAsymmetry >= 0.45f) {
        accumulatedParallaxHits++
      }
      if (meanTemporalMotion >= 0.85f && !isStaticSpoofSuspected) {
        accumulatedOrganicEntropyHits++
      }

      val stage1Done = consecutiveValidOpticalFrames >= 6
      val stage2Done = stage1Done && accumulatedParallaxHits >= 5
      val stage3Done = stage2Done && accumulatedOrganicEntropyHits >= 12

      val progress =
        when {
          stage3Done -> 100
          stage2Done -> (68 + (accumulatedOrganicEntropyHits * 2.5f).toInt()).coerceIn(68, 96)
          stage1Done -> (32 + (accumulatedParallaxHits * 7)).coerceIn(32, 67)
          else -> (consecutiveValidOpticalFrames * 5).coerceIn(5, 30)
        }

      val now = System.currentTimeMillis()
      if (stage3Done) {
        completed = true
        onTelemetryUpdate(
          LivenessTelemetry(
            stageIndex = 3,
            progressPercent = 100,
            instructionArabic = "تم التحقق من البصمة الحية ثلاثية الأبعاد بنجاح!",
            opticalLuminance = meanLuma,
            temporalMotionScore = meanTemporalMotion,
            parallaxAsymmetryScore = parallaxAsymmetry,
            isSpoofSuspected = false,
            isVerifiedLive = true,
          )
        )
        onLivenessVerified()
      } else if (now - lastEmitTimeMs > 120L) {
        lastEmitTimeMs = now
        val instruction =
          when {
            isStaticSpoofSuspected ->
              "تحذير تزييف عميق: تم رصد إطار جامد يشبه صورة ثابتة! حرّك رأسك لإثبات الحيوية"
            !stage1Done -> "المرحلة 1/3: جاري تثبيت البصمة الضوئية للوجه..."
            !stage2Done -> "المرحلة 2/3: حرّك رأسك يميناً أو يساراً ببطء لفحص العمق ثلاثي الأبعاد"
            else -> "المرحلة 3/3: جاري ختم التوقيع الحيوي ومطابقة الإنتروبيا الزمنية..."
          }
        onTelemetryUpdate(
          LivenessTelemetry(
            stageIndex = if (!stage1Done) 1 else if (!stage2Done) 2 else 3,
            progressPercent = progress,
            instructionArabic = instruction,
            opticalLuminance = meanLuma,
            temporalMotionScore = meanTemporalMotion,
            parallaxAsymmetryScore = parallaxAsymmetry,
            isSpoofSuspected = isStaticSpoofSuspected,
            spoofWarningArabic =
              if (isStaticSpoofSuspected) "تم رصد ثبات غير طبيعي (احتمال صورة ثابتة)" else "",
          )
        )
      }
    } catch (e: Exception) {
      onAnalyzerError(e.localizedMessage ?: "خطأ في تحليل إطار الكاميرا الحيوي")
    } finally {
      try {
        image.close()
      } catch (_: Exception) {}
    }
  }
}
