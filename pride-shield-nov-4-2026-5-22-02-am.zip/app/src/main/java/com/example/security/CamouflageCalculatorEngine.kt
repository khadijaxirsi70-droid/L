package com.example.security

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

sealed class CalcEvaluationResult {
  data class Success(val formattedValue: String) : CalcEvaluationResult()

  data class Error(val errorArabic: String) : CalcEvaluationResult()
}

/**
 * Precision Arithmetic Evaluator for the Camouflage Calculator.
 * Wrapped completely in try-catch so invalid expressions or division by zero never crash.
 */
object CamouflageCalculatorEngine {

  fun evaluateExpression(rawExpression: String): CalcEvaluationResult {
    return try {
      val normalized =
        rawExpression
          .replace("×", "*")
          .replace("÷", "/")
          .replace("−", "-")
          .replace(",", "")
          .trim()

      if (normalized.isEmpty()) {
        return CalcEvaluationResult.Success("0")
      }

      val tokens = tokenize(normalized)
      if (tokens.isEmpty()) {
        return CalcEvaluationResult.Success("0")
      }

      val result = evaluateTokens(tokens)
      val stripped = result.stripTrailingZeros()
      val formatted =
        if (stripped.scale() <= 0 && stripped.abs() < BigDecimal("1000000000000")) {
          stripped.toPlainString()
        } else if (stripped.abs() < BigDecimal("1000000000000")) {
          stripped.setScale(8.coerceAtMost(stripped.scale()), RoundingMode.HALF_UP)
            .stripTrailingZeros()
            .toPlainString()
        } else {
          stripped.round(MathContext(10, RoundingMode.HALF_UP)).toEngineeringString()
        }

      CalcEvaluationResult.Success(formatted)
    } catch (arith: ArithmeticException) {
      CalcEvaluationResult.Error(arith.message ?: "لا يمكن القسمة على صفر")
    } catch (_: Exception) {
      CalcEvaluationResult.Error("عملية غير صالحة")
    }
  }

  private fun tokenize(expr: String): List<String> {
    val tokens = mutableListOf<String>()
    val numberBuffer = StringBuilder()

    for (i in expr.indices) {
      val ch = expr[i]
      when {
        ch.isDigit() || ch == '.' -> numberBuffer.append(ch)
        ch == '-' && (i == 0 || expr[i - 1] in charArrayOf('+', '-', '*', '/', '%')) -> {
          numberBuffer.append(ch)
        }
        ch in charArrayOf('+', '-', '*', '/', '%') -> {
          if (numberBuffer.isNotEmpty()) {
            tokens.add(numberBuffer.toString())
            numberBuffer.clear()
          }
          tokens.add(ch.toString())
        }
        ch.isWhitespace() -> Unit
      }
    }
    if (numberBuffer.isNotEmpty()) {
      tokens.add(numberBuffer.toString())
    }
    // Drop trailing dangling operator if user pressed '=' right after '+'
    while (tokens.isNotEmpty() && tokens.last() in listOf("+", "-", "*", "/")) {
      tokens.removeAt(tokens.lastIndex)
    }
    return tokens
  }

  private fun evaluateTokens(tokens: List<String>): BigDecimal {
    // Handle unary '%' postfix (divide preceding number by 100)
    val step1 = mutableListOf<String>()
    for (token in tokens) {
      if (token == "%" && step1.isNotEmpty()) {
        val prev = BigDecimal(step1.removeAt(step1.lastIndex))
        step1.add(prev.divide(BigDecimal(100), 12, RoundingMode.HALF_UP).toPlainString())
      } else if (token != "%") {
        step1.add(token)
      }
    }

    // Pass 1: * and /
    val step2 = mutableListOf<String>()
    var i = 0
    while (i < step1.size) {
      val tok = step1[i]
      if ((tok == "*" || tok == "/") && step2.isNotEmpty() && i + 1 < step1.size) {
        val left = BigDecimal(step2.removeAt(step2.lastIndex))
        val right = BigDecimal(step1[i + 1])
        val computed =
          if (tok == "*") {
            left.multiply(right, MathContext.DECIMAL64)
          } else {
            if (right.compareTo(BigDecimal.ZERO) == 0) {
              throw ArithmeticException("لا يمكن القسمة على صفر")
            }
            left.divide(right, 10, RoundingMode.HALF_UP)
          }
        step2.add(computed.toPlainString())
        i += 2
      } else {
        step2.add(tok)
        i++
      }
    }

    // Pass 2: + and -
    if (step2.isEmpty()) return BigDecimal.ZERO
    var acc = BigDecimal(step2[0])
    var j = 1
    while (j + 1 < step2.size) {
      val op = step2[j]
      val right = BigDecimal(step2[j + 1])
      acc =
        when (op) {
          "+" -> acc.add(right)
          "-" -> acc.subtract(right)
          else -> acc
        }
      j += 2
    }
    return acc
  }
}
