package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.StatusBannerMessage
import com.example.ui.theme.LocalCyberColors

/**
 * 2028 Obsidian Black background with a glowing Electric Blue & Ultraviolet Purple Security Grid
 * and animated quantum scanline pulse. Uses DrawScope dimensions exclusively.
 */
@Composable
fun CyberSecurityGridBackground(
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit,
) {
  val cyberColors = LocalCyberColors.current
  val bgBlack = MaterialTheme.colorScheme.background

  val infiniteTransition = rememberInfiniteTransition(label = "cyber_grid_pulse")
  val scanProgress by
    infiniteTransition.animateFloat(
      initialValue = 0f,
      targetValue = 1f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 6500, easing = LinearEasing),
          repeatMode = RepeatMode.Restart,
        ),
      label = "grid_scan_y",
    )

  val nodeGlowAlpha by
    infiniteTransition.animateFloat(
      initialValue = 0.14f,
      targetValue = 0.34f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 2800, easing = LinearEasing),
          repeatMode = RepeatMode.Reverse,
        ),
      label = "node_glow_alpha",
    )

  Box(modifier = modifier.fillMaxSize().background(bgBlack)) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      if (w <= 0f || h <= 0f) return@Canvas

      // Ambient top-right purple & top-left electric blue nebula glow
      drawCircle(
        brush =
          Brush.radialGradient(
            colors = listOf(cyberColors.gridBlue.copy(alpha = 0.13f), Color.Transparent),
            center = Offset(w * 0.15f, h * 0.12f),
            radius = w * 0.65f,
          ),
        radius = w * 0.65f,
        center = Offset(w * 0.15f, h * 0.12f),
      )

      drawCircle(
        brush =
          Brush.radialGradient(
            colors = listOf(cyberColors.gridPurple.copy(alpha = 0.15f), Color.Transparent),
            center = Offset(w * 0.88f, h * 0.28f),
            radius = w * 0.7f,
          ),
        radius = w * 0.7f,
        center = Offset(w * 0.88f, h * 0.28f),
      )

      val step = 44.dp.toPx().coerceAtLeast(24f)

      // Vertical Blue Security Mesh Lines
      var x = 0f
      var colIndex = 0
      while (x <= w) {
        val lineColor =
          if (colIndex % 2 == 0) cyberColors.gridBlue.copy(alpha = 0.11f)
          else cyberColors.gridPurple.copy(alpha = 0.09f)
        drawLine(
          color = lineColor,
          start = Offset(x, 0f),
          end = Offset(x, h),
          strokeWidth = 1.dp.toPx(),
        )
        x += step
        colIndex++
      }

      // Horizontal Purple/Blue Security Mesh Lines
      var y = 0f
      var rowIndex = 0
      while (y <= h) {
        val lineColor =
          if (rowIndex % 2 == 0) cyberColors.gridPurple.copy(alpha = 0.11f)
          else cyberColors.gridBlue.copy(alpha = 0.09f)
        drawLine(
          color = lineColor,
          start = Offset(0f, y),
          end = Offset(w, y),
          strokeWidth = 1.dp.toPx(),
        )
        y += step
        rowIndex++
      }

      // Glowing intersection security nodes
      var nx = step
      var ni = 0
      while (nx < w) {
        var ny = step
        while (ny < h) {
          if (ni % 5 == 0) {
            drawCircle(
              color =
                if (ni % 2 == 0) cyberColors.gridBlue.copy(alpha = nodeGlowAlpha)
                else cyberColors.gridPurple.copy(alpha = nodeGlowAlpha),
              radius = 2.2.dp.toPx(),
              center = Offset(nx, ny),
            )
          }
          ny += step * 2
          ni++
        }
        nx += step * 2
      }

      // Sweeping holographic security laser line
      val scanY = h * scanProgress
      drawRect(
        brush =
          Brush.verticalGradient(
            colors =
              listOf(
                Color.Transparent,
                cyberColors.gridBlue.copy(alpha = 0.18f),
                cyberColors.gridPurple.copy(alpha = 0.24f),
                Color.Transparent,
              ),
            startY = (scanY - 36.dp.toPx()).coerceAtLeast(0f),
            endY = (scanY + 12.dp.toPx()).coerceAtMost(h),
          ),
        topLeft = Offset(0f, (scanY - 36.dp.toPx()).coerceAtLeast(0f)),
        size = androidx.compose.ui.geometry.Size(w, 48.dp.toPx()),
      )
    }

    content()
  }
}

@Composable
fun CyberGlassCard(
  modifier: Modifier = Modifier,
  borderColor: Color = LocalCyberColors.current.gridBlue.copy(alpha = 0.35f),
  containerColor: Color = LocalCyberColors.current.surfaceGlass,
  content: @Composable ColumnScope.() -> Unit,
) {
  Card(
    modifier = modifier,
    shape = MaterialTheme.shapes.medium,
    colors = CardDefaults.cardColors(containerColor = containerColor),
    border = BorderStroke(1.dp, borderColor),
  ) {
    Column(modifier = Modifier.padding(16.dp), content = content)
  }
}

@Composable
fun CyberAlertBanner(
  banner: StatusBannerMessage?,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val cyberColors = LocalCyberColors.current

  AnimatedVisibility(visible = banner != null, enter = fadeIn(), exit = fadeOut()) {
    if (banner != null) {
      val accentColor =
        when {
          banner.isWarningRed -> cyberColors.warningRed
          banner.isSuccessYellow -> cyberColors.successYellow
          else -> cyberColors.gridBlue
        }
      val bgColor =
        when {
          banner.isWarningRed -> cyberColors.warningRedContainer
          banner.isSuccessYellow -> cyberColors.successYellowContainer
          else -> MaterialTheme.colorScheme.surfaceVariant
        }

      Row(
        modifier =
          modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .border(1.5.dp, accentColor, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("cyber_alert_banner"),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(
          modifier =
            Modifier.size(36.dp)
              .clip(CircleShape)
              .background(accentColor.copy(alpha = 0.18f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector =
              if (banner.isWarningRed) Icons.Filled.Warning else Icons.Filled.CheckCircle,
            contentDescription = banner.title,
            tint = accentColor,
            modifier = Modifier.size(20.dp),
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
          Text(
            text = banner.title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = accentColor,
          )
          Text(
            text = banner.subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
          )
        }
        IconButton(
          onClick = onDismiss,
          modifier = Modifier.testTag("dismiss_alert_banner_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "إغلاق التنبيه",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    }
  }
}

@Composable
fun CyberSemanticPill(
  text: String,
  accentColor: Color,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier =
      modifier
        .clip(RoundedCornerShape(50))
        .background(accentColor.copy(alpha = 0.15f))
        .border(1.dp, accentColor.copy(alpha = 0.55f), RoundedCornerShape(50))
        .padding(horizontal = 10.dp, vertical = 4.dp)
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.labelSmall,
      color = accentColor,
      fontWeight = FontWeight.Bold,
    )
  }
}
