package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddModerator
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.VaultFileEntity
import com.example.ui.DecryptedPreviewDialogState
import com.example.ui.components.CyberGlassCard
import com.example.ui.components.CyberSemanticPill
import com.example.ui.theme.CyberMonoFontFamily
import com.example.ui.theme.LocalCyberColors

@Composable
fun QuantumVaultTab(
  vaultFiles: List<VaultFileEntity>,
  totalRamBytesWiped: Long,
  isCryptoBusy: Boolean,
  decryptedPreview: DecryptedPreviewDialogState?,
  onEncryptPickedFile: (Uri, String) -> Unit,
  onEncryptSecretNote: (title: String, content: String, passphrase: String, simulateFault: Boolean) -> Unit,
  onDecryptItem: (VaultFileEntity, String) -> Unit,
  onRetryQuarantineItem: (VaultFileEntity, String) -> Unit,
  onShredItem: (VaultFileEntity) -> Unit,
  onClosePreview: () -> Unit,
) {
  val cyberColors = LocalCyberColors.current

  var vaultPassphrase by rememberSaveable { mutableStateOf("2028") }
  var showNewSecretDialog by rememberSaveable { mutableStateOf(false) }
  var noteTitle by rememberSaveable { mutableStateOf("") }
  var noteContent by rememberSaveable { mutableStateOf("") }

  val filePickerLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
      if (uri != null) {
        onEncryptPickedFile(uri, vaultPassphrase)
      }
    }

  val encryptedItems = vaultFiles.filter { it.isEncrypted && !it.isQuarantined }
  val quarantinedItems = vaultFiles.filter { it.isQuarantined }

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("quantum_vault_tab"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    // Vault Header & RAM Key Shredder Status
    item {
      CyberGlassCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = cyberColors.gridBlue.copy(alpha = 0.6f),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          CyberSemanticPill(text = "AES-256-GCM // PBKDF2", accentColor = cyberColors.gridBlue)
          CyberSemanticPill(
            text = "RAM ZEROIZED: ${totalRamBytesWiped}B",
            accentColor = cyberColors.successYellow,
          )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = stringResource(R.string.vault_title),
          style = MaterialTheme.typography.headlineMedium,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = stringResource(R.string.vault_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Session Key Input (Zeroized in Crypto Engine after every call)
        OutlinedTextField(
          value = vaultPassphrase,
          onValueChange = { vaultPassphrase = it },
          label = { Text("مفتاح الخزنة المؤقت (يُدمّر من RAM بعد كل عملية)") },
          singleLine = true,
          visualTransformation = PasswordVisualTransformation(),
          modifier = Modifier.fillMaxWidth().testTag("vault_passphrase_input"),
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Primary Encryption Actions
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Button(
            onClick = {
              try {
                filePickerLauncher.launch(arrayOf("*/*"))
              } catch (_: Exception) {
                showNewSecretDialog = true
              }
            },
            enabled = !isCryptoBusy,
            colors =
              ButtonDefaults.buttonColors(
                containerColor = cyberColors.gridBlue,
                contentColor = Color.Black,
              ),
            modifier =
              Modifier.weight(1f)
                .height(50.dp)
                .minimumInteractiveComponentSize()
                .testTag("encrypt_device_file_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.FileOpen,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = stringResource(R.string.vault_btn_pick_file),
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.labelLarge,
            )
          }

          Button(
            onClick = { showNewSecretDialog = true },
            enabled = !isCryptoBusy,
            colors =
              ButtonDefaults.buttonColors(
                containerColor = cyberColors.gridPurple,
                contentColor = Color.White,
              ),
            modifier =
              Modifier.weight(1f)
                .height(50.dp)
                .minimumInteractiveComponentSize()
                .testTag("encrypt_secret_note_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.AddModerator,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = stringResource(R.string.vault_btn_new_secret),
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Fault Injection Button to Demonstrate Isolated Quarantine Sandbox Rule
        OutlinedButton(
          onClick = {
            onEncryptSecretNote(
              "ملف_اختبار_الطوارئ_${System.currentTimeMillis() % 1000}.dat",
              "بيانات حساسة لاختبار بروتوكول العزل الآمن عند تعذر التشفير الكمي.",
              vaultPassphrase,
              true,
            )
          },
          enabled = !isCryptoBusy,
          border = BorderStroke(1.dp, cyberColors.warningRed.copy(alpha = 0.75f)),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = cyberColors.warningRed),
          modifier =
            Modifier.fillMaxWidth()
              .height(48.dp)
              .minimumInteractiveComponentSize()
              .testTag("test_quarantine_fault_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.BugReport,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.vault_btn_test_quarantine),
            fontWeight = FontWeight.Bold,
          )
        }

        if (isCryptoBusy) {
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              strokeWidth = 2.dp,
              color = cyberColors.successYellow,
            )
            Text(
              text = "جاري تنفيذ AES-256 وتصفير قطاعات المفتاح في الذاكرة العشوائية...",
              style = MaterialTheme.typography.bodySmall,
              color = cyberColors.successYellow,
            )
          }
        }
      }
    }

    // Isolated Quarantine Sandbox Section (Fiery Red Warning Accent)
    if (quarantinedItems.isNotEmpty()) {
      item {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.GppBad,
            contentDescription = null,
            tint = cyberColors.warningRed,
          )
          Text(
            text = "${stringResource(R.string.vault_section_quarantine)} (${quarantinedItems.size})",
            style = MaterialTheme.typography.titleMedium,
            color = cyberColors.warningRed,
            fontWeight = FontWeight.Bold,
          )
        }
      }

      items(quarantinedItems, key = { "quarantine_${it.id}" }) { item ->
        QuarantinedFileCard(
          item = item,
          onRetryEncrypt = { onRetryQuarantineItem(item, vaultPassphrase) },
          onShred = { onShredItem(item) },
        )
      }
    }

    // Encrypted Vault Files Section (Cyber Yellow Success Accent)
    item {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.EnhancedEncryption,
          contentDescription = null,
          tint = cyberColors.successYellow,
        )
        Text(
          text = "${stringResource(R.string.vault_section_encrypted)} (${encryptedItems.size})",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onBackground,
          fontWeight = FontWeight.Bold,
        )
      }
    }

    if (encryptedItems.isEmpty() && quarantinedItems.isEmpty()) {
      item {
        CyberGlassCard(modifier = Modifier.fillMaxWidth()) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Memory,
              contentDescription = null,
              tint = cyberColors.gridBlue,
              modifier = Modifier.size(38.dp),
            )
            Text(
              text = stringResource(R.string.vault_empty_state),
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    } else {
      items(encryptedItems, key = { "enc_${it.id}" }) { item ->
        EncryptedVaultFileCard(
          item = item,
          onDecrypt = { onDecryptItem(item, vaultPassphrase) },
          onShred = { onShredItem(item) },
        )
      }
    }
  }

  // Modal to Author & Encrypt a Classified Secret Document
  if (showNewSecretDialog) {
    BackHandler { showNewSecretDialog = false }
    AlertDialog(
      onDismissRequest = { showNewSecretDialog = false },
      title = { Text("تشفير وثيقة سرية بمعيار AES-256") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = noteTitle,
            onValueChange = { noteTitle = it },
            label = { Text("عنوان الوثيقة (مثال: مفاتيح المحفظة)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("secret_note_title_input"),
          )
          OutlinedTextField(
            value = noteContent,
            onValueChange = { noteContent = it },
            label = { Text("النص السري المراد تشفيره") },
            minLines = 3,
            maxLines = 6,
            modifier = Modifier.fillMaxWidth().testTag("secret_note_body_input"),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onEncryptSecretNote(noteTitle, noteContent, vaultPassphrase, false)
            noteTitle = ""
            noteContent = ""
            showNewSecretDialog = false
          },
          colors =
            ButtonDefaults.buttonColors(
              containerColor = cyberColors.successYellow,
              contentColor = Color.Black,
            ),
          modifier = Modifier.testTag("confirm_encrypt_note_button"),
        ) {
          Text("تشفير وتدمير المفتاح من RAM", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showNewSecretDialog = false }) { Text("إلغاء") }
      },
    )
  }

  // Modal to Preview Decrypted Payload & RAM Wipe Proof
  if (decryptedPreview != null) {
    BackHandler { onClosePreview() }
    AlertDialog(
      onDismissRequest = onClosePreview,
      title = {
        Text(
          text = "معاينة آمنة: ${decryptedPreview.fileName}",
          color = cyberColors.successYellow,
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(cyberColors.successYellowContainer)
                .border(1.dp, cyberColors.successYellow, RoundedCornerShape(10.dp))
                .padding(10.dp)
          ) {
            Text(
              text =
                "تم تصفير المفتاح في RAM بنجاح: ${decryptedPreview.ramWipeReport.bytesZeroized} بايت (${decryptedPreview.ramWipeReport.passesCompleted} مراحل مسح 0x00)",
              style = MaterialTheme.typography.bodySmall,
              color = cyberColors.successYellow,
              fontWeight = FontWeight.Bold,
            )
          }

          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(12.dp)
          ) {
            Text(
              text = decryptedPreview.previewText,
              fontFamily = CyberMonoFontFamily,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface,
            )
          }

          Text(
            text = "SHA-256: ${decryptedPreview.sha256Digest.take(28)}...",
            fontFamily = CyberMonoFontFamily,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      },
      confirmButton = {
        Button(
          onClick = onClosePreview,
          colors = ButtonDefaults.buttonColors(containerColor = cyberColors.gridBlue),
          modifier = Modifier.testTag("close_decrypted_preview_button"),
        ) {
          Text("إغلاق وتصفير المعاينة", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
    )
  }
}

@Composable
private fun EncryptedVaultFileCard(
  item: VaultFileEntity,
  onDecrypt: () -> Unit,
  onShred: () -> Unit,
) {
  val cyberColors = LocalCyberColors.current

  CyberGlassCard(
    modifier = Modifier.fillMaxWidth().testTag("vault_encrypted_card_${item.id}"),
    borderColor = cyberColors.successYellow.copy(alpha = 0.45f),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = item.originalName,
        style = MaterialTheme.typography.titleMedium,
        color = cyberColors.successYellow,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.weight(1f),
      )
      CyberSemanticPill(
        text = "RAM WIPED ${item.ramBytesZeroized}B",
        accentColor = cyberColors.successYellow,
      )
    }

    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text =
        "الحجم المشفر: ${item.sizeBytes} B  |  IV: ${item.ivHex.take(12)}...  |  SHA-256: ${item.sha256Digest.take(14)}...",
      fontFamily = CyberMonoFontFamily,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Spacer(modifier = Modifier.height(10.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Button(
        onClick = onDecrypt,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = cyberColors.gridBlue,
            contentColor = Color.Black,
          ),
        modifier =
          Modifier.weight(1f)
            .minimumInteractiveComponentSize()
            .testTag("decrypt_item_button_${item.id}"),
      ) {
        Icon(
          imageVector = Icons.Filled.LockOpen,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = stringResource(R.string.vault_decrypt_action),
          style = MaterialTheme.typography.labelLarge,
        )
      }

      OutlinedButton(
        onClick = onShred,
        border = BorderStroke(1.dp, cyberColors.warningRed.copy(alpha = 0.6f)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = cyberColors.warningRed),
        modifier =
          Modifier.minimumInteractiveComponentSize().testTag("shred_item_button_${item.id}"),
      ) {
        Icon(
          imageVector = Icons.Filled.DeleteForever,
          contentDescription = stringResource(R.string.vault_shred_action),
          modifier = Modifier.size(18.dp),
        )
      }
    }
  }
}

@Composable
private fun QuarantinedFileCard(
  item: VaultFileEntity,
  onRetryEncrypt: () -> Unit,
  onShred: () -> Unit,
) {
  val cyberColors = LocalCyberColors.current

  CyberGlassCard(
    modifier = Modifier.fillMaxWidth().testTag("vault_quarantine_card_${item.id}"),
    borderColor = cyberColors.warningRed,
    containerColor = cyberColors.warningRedContainer.copy(alpha = 0.85f),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = item.originalName,
        style = MaterialTheme.typography.titleMedium,
        color = cyberColors.warningRed,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.weight(1f),
      )
      CyberSemanticPill(text = "مساحة معزولة آمنة", accentColor = cyberColors.warningRed)
    }

    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = "سبب العزل التلقائي: ${item.quarantineReason}",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurface,
    )
    Text(
      text = "المسار المعزول: MODE_PRIVATE/isolated_quarantine_sandbox (${item.sizeBytes} B)",
      fontFamily = CyberMonoFontFamily,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Spacer(modifier = Modifier.height(10.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Button(
        onClick = onRetryEncrypt,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = cyberColors.successYellow,
            contentColor = Color.Black,
          ),
        modifier =
          Modifier.weight(1f)
            .minimumInteractiveComponentSize()
            .testTag("retry_quarantine_button_${item.id}"),
      ) {
        Icon(
          imageVector = Icons.Filled.Refresh,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = stringResource(R.string.vault_retry_encrypt_action),
          fontWeight = FontWeight.Bold,
          style = MaterialTheme.typography.labelLarge,
        )
      }

      OutlinedButton(
        onClick = onShred,
        border = BorderStroke(1.dp, cyberColors.warningRed),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = cyberColors.warningRed),
        modifier =
          Modifier.minimumInteractiveComponentSize()
            .testTag("shred_quarantine_button_${item.id}"),
      ) {
        Icon(
          imageVector = Icons.Filled.DeleteForever,
          contentDescription = stringResource(R.string.vault_shred_action),
          modifier = Modifier.size(18.dp),
        )
      }
    }
  }
}
