package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CameraFront
import androidx.compose.material.icons.filled.FaceRetouchingNatural
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.R
import com.example.security.DeepfakeLivenessAnalyzer
import com.example.security.LivenessTelemetry
import com.example.ui.AuthSubMode
import com.example.ui.components.CyberGlassCard
import com.example.ui.components.CyberSecurityGridBackground
import com.example.ui.components.CyberSemanticPill
import com.example.ui.theme.CyberMonoFontFamily
import com.example.ui.theme.LocalCyberColors
import java.util.concurrent.Executors

@Composable
fun DeepfakeAuthScreen(
  authSubMode: AuthSubMode,
  cameraFallbackReason: String,
  pinAuthError: String,
  isDefaultCodeActive: Boolean,
  onCameraFailedFallbackToPin: (String) -> Unit,
  onSwitchBackToCamera: () -> Unit,
  onLivenessVerified: () -> Unit,
  onSubmitEmergencyPin: (String) -> Unit,
  onReturnToCamouflage: () -> Unit,
) {
  BackHandler { onReturnToCamouflage() }

  val context = LocalContext.current
  val cyberColors = LocalCyberColors.current

  var hasCameraPermission by remember {
    mutableStateOf(
      try {
        ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
          PackageManager.PERMISSION_GRANTED
      } catch (_: Exception) {
        false
      }
    )
  }

  val cameraPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      hasCameraPermission = granted
      if (!granted) {
        onCameraFailedFallbackToPin(
          "تم رفض صلاحية الكاميرا — جرى التفعيل التلقائي لرمز المرور الاحتياطي (PIN)."
        )
      }
    }

  CyberSecurityGridBackground {
    Box(
      modifier =
        Modifier.fillMaxSize()
          .windowInsetsPadding(WindowInsets.safeDrawing)
          .testTag("deepfake_auth_screen"),
      contentAlignment = Alignment.Center,
    ) {
      Column(
        modifier =
          Modifier.fillMaxSize()
            .widthIn(max = 560.dp)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        // Header Badge & Title
        CyberSemanticPill(
          text = "2028 ANTI-DEEPFAKE BIO-SHIELD",
          accentColor = cyberColors.gridPurple,
        )

        Text(
          text = stringResource(R.string.auth_screen_title),
          style = MaterialTheme.typography.headlineMedium,
          color = MaterialTheme.colorScheme.onBackground,
          textAlign = TextAlign.Center,
        )

        Text(
          text = stringResource(R.string.auth_screen_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          textAlign = TextAlign.Center,
        )

        when (authSubMode) {
          AuthSubMode.CAMERA_LIVENESS -> {
            if (!hasCameraPermission) {
              CameraPermissionGateCard(
                onRequestPermission = {
                  try {
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                  } catch (e: Exception) {
                    onCameraFailedFallbackToPin(
                      "تعذر طلب مستشعر الكاميرا (${e.localizedMessage ?: "خطأ نظام"}) — انتقل إلى PIN."
                    )
                  }
                },
                onUsePinFallback = {
                  onCameraFailedFallbackToPin(
                    "تم اختيار بروتوكول الطوارئ (PIN) بدلاً من الكاميرا الحيوية."
                  )
                },
              )
            } else {
              LiveCameraLivenessHud(
                onLivenessVerified = onLivenessVerified,
                onCameraError = { errReason -> onCameraFailedFallbackToPin(errReason) },
              )
            }

            // Action row to simulate camera fault (tests Error Engineering rule) or switch to PIN
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              OutlinedButton(
                onClick = {
                  onCameraFailedFallbackToPin(
                    "انقطاع مستشعر الكاميرا الأمامية (عطل عتادي) — تم التحويل الفوري لبروتوكول PIN."
                  )
                },
                border = BorderStroke(1.dp, cyberColors.warningRed.copy(alpha = 0.7f)),
                colors =
                  ButtonDefaults.outlinedButtonColors(contentColor = cyberColors.warningRed),
                modifier =
                  Modifier.weight(1f)
                    .minimumInteractiveComponentSize()
                    .testTag("simulate_camera_failure_button"),
              ) {
                Icon(
                  imageVector = Icons.Filled.BugReport,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = stringResource(R.string.auth_simulate_cam_fail_btn),
                  style = MaterialTheme.typography.labelLarge,
                )
              }

              OutlinedButton(
                onClick = {
                  onCameraFailedFallbackToPin("تم التبديل اليدوي إلى مصادقة رمز المرور (PIN).")
                },
                border = BorderStroke(1.dp, cyberColors.gridBlue.copy(alpha = 0.7f)),
                modifier =
                  Modifier.weight(1f)
                    .minimumInteractiveComponentSize()
                    .testTag("switch_to_pin_button"),
              ) {
                Icon(
                  imageVector = Icons.Filled.Password,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = stringResource(R.string.auth_switch_to_pin_btn),
                  style = MaterialTheme.typography.labelLarge,
                )
              }
            }
          }

          AuthSubMode.EMERGENCY_PIN_FALLBACK -> {
            EmergencyPinFallbackCard(
              fallbackReason = cameraFallbackReason,
              pinError = pinAuthError,
              isDefaultCodeActive = isDefaultCodeActive,
              onSubmitPin = onSubmitEmergencyPin,
              onRetryCamera = onSwitchBackToCamera,
            )
          }
        }

        TextButton(
          onClick = onReturnToCamouflage,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("return_to_camouflage_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.Lock,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = stringResource(R.string.auth_return_camouflage_btn),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    }
  }
}

@Composable
private fun CameraPermissionGateCard(
  onRequestPermission: () -> Unit,
  onUsePinFallback: () -> Unit,
) {
  val cyberColors = LocalCyberColors.current

  CyberGlassCard(
    modifier = Modifier.fillMaxWidth(),
    borderColor = cyberColors.gridBlue.copy(alpha = 0.55f),
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(14.dp),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Box(
        modifier =
          Modifier.size(120.dp)
            .clip(CircleShape)
            .border(2.dp, cyberColors.gridPurple, CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Image(
          painter = painterResource(id = R.drawable.img_liveness_mesh),
          contentDescription = stringResource(R.string.cd_liveness_mesh),
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
      }

      Text(
        text = stringResource(R.string.auth_camera_permission_prompt),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center,
      )

      Button(
        onClick = onRequestPermission,
        colors = ButtonDefaults.buttonColors(containerColor = cyberColors.gridBlue),
        modifier =
          Modifier.fillMaxWidth()
            .height(50.dp)
            .testTag("grant_camera_permission_button"),
      ) {
        Icon(imageVector = Icons.Filled.CameraFront, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = stringResource(R.string.auth_grant_camera_btn),
          color = Color.Black,
          fontWeight = FontWeight.Bold,
        )
      }

      OutlinedButton(
        onClick = onUsePinFallback,
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("permission_card_pin_button"),
      ) {
        Text(text = stringResource(R.string.auth_switch_to_pin_btn))
      }
    }
  }
}

@Composable
private fun LiveCameraLivenessHud(
  onLivenessVerified: () -> Unit,
  onCameraError: (String) -> Unit,
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val cyberColors = LocalCyberColors.current

  var telemetry by remember {
    mutableStateOf(
      LivenessTelemetry(
        stageIndex = 1,
        progressPercent = 8,
        instructionArabic = "جاري معايرة المستشعر الحيوي ثلاثي الأبعاد...",
        opticalLuminance = 0,
        temporalMotionScore = 0f,
        parallaxAsymmetryScore = 0f,
        isSpoofSuspected = false,
      )
    )
  }

  val analysisExecutor = remember { Executors.newSingleThreadExecutor() }

  DisposableEffect(Unit) {
    onDispose {
      try {
        analysisExecutor.shutdown()
      } catch (_: Exception) {}
    }
  }

  CyberGlassCard(
    modifier = Modifier.fillMaxWidth(),
    borderColor =
      when {
        telemetry.isVerifiedLive -> cyberColors.successYellow
        telemetry.isSpoofSuspected -> cyberColors.warningRed
        else -> cyberColors.gridBlue
      },
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.fillMaxWidth(),
    ) {
      // Biometric Circular HUD Viewport
      Box(
        modifier =
          Modifier.size(230.dp)
            .clip(CircleShape)
            .border(
              width = 3.dp,
              color =
                when {
                  telemetry.isVerifiedLive -> cyberColors.successYellow
                  telemetry.isSpoofSuspected -> cyberColors.warningRed
                  else -> cyberColors.gridPurple
                },
              shape = CircleShape,
            )
            .testTag("camera_liveness_viewport"),
        contentAlignment = Alignment.Center,
      ) {
        AndroidView(
          factory = { ctx ->
            val previewView =
              PreviewView(ctx).apply {
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                scaleType = PreviewView.ScaleType.FILL_CENTER
              }

            try {
              val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
              cameraProviderFuture.addListener(
                {
                  try {
                    val cameraProvider = cameraProviderFuture.get()
                    val availableSelector =
                      when {
                        cameraProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) ->
                          CameraSelector.DEFAULT_FRONT_CAMERA
                        cameraProvider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) ->
                          CameraSelector.DEFAULT_BACK_CAMERA
                        else -> null
                      }

                    if (availableSelector == null) {
                      onCameraError(
                        "لم يتم العثور على مستشعر كاميرا متاح على الجهاز — تم التفعيل التلقائي لرمز المرور (PIN)."
                      )
                      return@addListener
                    }

                    val preview =
                      Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                      }

                    val imageAnalysis =
                      ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                        .also { analysis ->
                          analysis.setAnalyzer(
                            analysisExecutor,
                            DeepfakeLivenessAnalyzer(
                              onTelemetryUpdate = { updated -> telemetry = updated },
                              onLivenessVerified = onLivenessVerified,
                              onAnalyzerError = { msg -> onCameraError(msg) },
                            ),
                          )
                        }

                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                      lifecycleOwner,
                      availableSelector,
                      preview,
                      imageAnalysis,
                    )
                  } catch (bindEx: Exception) {
                    onCameraError(
                      "فشل ربط مستشعر الكاميرا (${bindEx.localizedMessage ?: "خطأ عتادي"}) — انتقل لرمز PIN."
                    )
                  }
                },
                ContextCompat.getMainExecutor(ctx),
              )
            } catch (initEx: Exception) {
              onCameraError(
                "تعذر تشغيل محرك الكاميرا (${initEx.localizedMessage ?: "خطأ تهيئة"}) — انتقل لرمز PIN."
              )
            }
            previewView
          },
          modifier = Modifier.fillMaxSize(),
        )

        // Subtle holographic 3D wireframe mesh overlay
        Image(
          painter = painterResource(id = R.drawable.img_liveness_mesh),
          contentDescription = null,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize().alpha(0.22f),
        )
      }

      // Live Stage & Progress Bar
      LinearProgressIndicator(
        progress = { telemetry.progressPercent / 100f },
        color =
          when {
            telemetry.isVerifiedLive -> cyberColors.successYellow
            telemetry.isSpoofSuspected -> cyberColors.warningRed
            else -> cyberColors.gridBlue
          },
        trackColor = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
      )

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector =
            if (telemetry.isSpoofSuspected) Icons.Filled.Warning
            else Icons.Filled.FaceRetouchingNatural,
          contentDescription = null,
          tint =
            when {
              telemetry.isVerifiedLive -> cyberColors.successYellow
              telemetry.isSpoofSuspected -> cyberColors.warningRed
              else -> cyberColors.gridBlue
            },
          modifier = Modifier.size(20.dp),
        )
        Text(
          text = telemetry.instructionArabic,
          style = MaterialTheme.typography.titleSmall,
          color =
            when {
              telemetry.isVerifiedLive -> cyberColors.successYellow
              telemetry.isSpoofSuspected -> cyberColors.warningRed
              else -> MaterialTheme.colorScheme.onSurface
            },
          textAlign = TextAlign.Center,
        )
      }

      // Live Optical & Anti-Deepfake Telemetry Metrics
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        TelemetryChip(label = "إضاءة البصمة", value = "${telemetry.opticalLuminance}")
        TelemetryChip(
          label = "تدفق حيوي",
          value = "%.1f".format(telemetry.temporalMotionScore),
        )
        TelemetryChip(
          label = "عمق 3D",
          value = "%.2f".format(telemetry.parallaxAsymmetryScore),
        )
      }
    }
  }
}

@Composable
private fun TelemetryChip(label: String, value: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Text(
      text = value,
      fontFamily = CyberMonoFontFamily,
      fontSize = 13.sp,
      fontWeight = FontWeight.Bold,
      color = LocalCyberColors.current.gridBlue,
    )
  }
}

@Composable
private fun EmergencyPinFallbackCard(
  fallbackReason: String,
  pinError: String,
  isDefaultCodeActive: Boolean,
  onSubmitPin: (String) -> Unit,
  onRetryCamera: () -> Unit,
) {
  val cyberColors = LocalCyberColors.current
  var pinValue by rememberSaveable { mutableStateOf("") }

  LaunchedEffect(pinError) {
    if (pinError.isNotEmpty()) {
      pinValue = ""
    }
  }

  CyberGlassCard(
    modifier = Modifier.fillMaxWidth().testTag("emergency_pin_card"),
    borderColor = cyberColors.warningRed.copy(alpha = 0.7f),
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.fillMaxWidth(),
    ) {
      if (fallbackReason.isNotBlank()) {
        Row(
          modifier =
            Modifier.fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(cyberColors.warningRedContainer)
              .border(1.dp, cyberColors.warningRed, RoundedCornerShape(12.dp))
              .padding(12.dp)
              .testTag("camera_failure_warning_box"),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Filled.Warning,
            contentDescription = null,
            tint = cyberColors.warningRed,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = fallbackReason,
            style = MaterialTheme.typography.bodySmall,
            color = cyberColors.warningRed,
            fontWeight = FontWeight.SemiBold,
          )
        }
      }

      Text(
        text = stringResource(R.string.auth_pin_title),
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onBackground,
      )

      if (isDefaultCodeActive) {
        Text(
          text = stringResource(R.string.auth_pin_default_hint),
          style = MaterialTheme.typography.bodySmall,
          color = cyberColors.successYellow,
          textAlign = TextAlign.Center,
        )
      }

      // Masked PIN Dots Display
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(vertical = 6.dp).testTag("pin_dots_display"),
        ) {
          val slotCount = maxOf(4, pinValue.length.coerceAtMost(8))
          for (i in 0 until slotCount) {
            val filled = i < pinValue.length
            Box(
              modifier =
                Modifier.size(18.dp)
                  .clip(CircleShape)
                  .background(
                    if (filled) cyberColors.gridBlue else Color.Transparent
                  )
                  .border(
                    1.5.dp,
                    if (filled) cyberColors.gridBlue else cyberColors.gridPurple,
                    CircleShape,
                  )
            )
          }
        }
      }

      if (pinError.isNotBlank()) {
        Text(
          text = pinError,
          style = MaterialTheme.typography.bodySmall,
          color = cyberColors.warningRed,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.testTag("pin_error_text"),
        )
      }

      // Tactical Numeric PIN Pad
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        val pinRows =
          listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("C", "0", "⌫"),
          )
        Column(
          verticalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          pinRows.forEach { row ->
            Row(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.fillMaxWidth(),
            ) {
              row.forEach { digit ->
                Surface(
                  modifier =
                    Modifier.weight(1f)
                      .height(52.dp)
                      .minimumInteractiveComponentSize()
                      .clip(RoundedCornerShape(12.dp))
                      .clickable {
                        when (digit) {
                          "C" -> pinValue = ""
                          "⌫" -> if (pinValue.isNotEmpty()) pinValue = pinValue.dropLast(1)
                          else -> if (pinValue.length < 8) pinValue += digit
                        }
                      }
                      .testTag("pin_pad_$digit"),
                  color = MaterialTheme.colorScheme.surfaceVariant,
                  border = BorderStroke(1.dp, cyberColors.borderSubtle),
                  shape = RoundedCornerShape(12.dp),
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    if (digit == "⌫") {
                      Icon(
                        imageVector = Icons.AutoMirrored.Filled.Backspace,
                        contentDescription = stringResource(R.string.cd_calc_backspace),
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp),
                      )
                    } else {
                      Text(
                        text = digit,
                        fontFamily = CyberMonoFontFamily,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color =
                          if (digit == "C") cyberColors.warningRed
                          else MaterialTheme.colorScheme.onSurface,
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }

      Button(
        onClick = { onSubmitPin(pinValue) },
        enabled = pinValue.length >= 4,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = cyberColors.successYellow,
            contentColor = Color.Black,
          ),
        modifier =
          Modifier.fillMaxWidth()
            .height(52.dp)
            .testTag("submit_emergency_pin_button"),
      ) {
        Text(
          text = stringResource(R.string.auth_pin_verify_btn),
          fontWeight = FontWeight.Bold,
          style = MaterialTheme.typography.titleMedium,
        )
      }

      TextButton(
        onClick = onRetryCamera,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("retry_camera_liveness_button"),
      ) {
        Icon(
          imageVector = Icons.Filled.CameraFront,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text("إعادة محاولة مستشعر الكاميرا الحيوي")
      }
    }
  }
}
