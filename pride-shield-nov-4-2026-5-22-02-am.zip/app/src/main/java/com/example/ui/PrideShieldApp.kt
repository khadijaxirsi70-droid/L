package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.EnhancedEncryption
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.ui.components.CyberAlertBanner
import com.example.ui.components.CyberSecurityGridBackground
import com.example.ui.screens.CamouflageCalculatorScreen
import com.example.ui.screens.CommandDashboardTab
import com.example.ui.screens.DeepfakeAuthScreen
import com.example.ui.screens.QuantumVaultTab
import com.example.ui.screens.SecuritySettingsTab
import com.example.ui.screens.ZeroTrustTab
import com.example.ui.theme.LocalCyberColors

private data class NavTabSpec(
  val tab: ShieldTab,
  val labelRes: Int,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val testTag: String,
)

@Composable
fun PrideShieldApp(viewModel: PrideShieldViewModel = viewModel()) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()

  // Provide RTL layout direction across the Arabic cyber security suite
  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
    Crossfade(targetState = uiState.gateState, label = "root_gate_transition") { gate ->
      when (gate) {
        RootGateState.CAMOUFLAGE_CALCULATOR -> {
          CamouflageCalculatorScreen(
            expression = uiState.calcInput,
            resultPreview = uiState.calcResultPreview,
            history = uiState.calcHistory,
            showFirstRunSetupHint = uiState.showCalculatorSetupHint,
            isDefaultCodeActive = uiState.isDefaultCodeActive,
            onKeyPress = viewModel::onCalculatorKeyPress,
            onEqualsPress = viewModel::onCalculatorEqualsPressed,
            onClearHistory = viewModel::clearCalculatorHistory,
            onDismissHint = viewModel::dismissCalculatorOnboardingHint,
          )
        }

        RootGateState.DEEPFAKE_BIOMETRIC_AUTH -> {
          DeepfakeAuthScreen(
            authSubMode = uiState.authSubMode,
            cameraFallbackReason = uiState.cameraFallbackReason,
            pinAuthError = uiState.pinAuthError,
            isDefaultCodeActive = uiState.isDefaultCodeActive,
            onCameraFailedFallbackToPin = viewModel::onCameraHardwareOrPermissionFailed,
            onSwitchBackToCamera = viewModel::switchToCameraLivenessMode,
            onLivenessVerified = viewModel::onLivenessVerifiedSuccess,
            onSubmitEmergencyPin = viewModel::submitEmergencyPin,
            onReturnToCamouflage = viewModel::triggerPanicCamouflage,
          )
        }

        RootGateState.PRIDE_SHIELD_UNLOCKED -> {
          PrideShieldCommandShell(uiState = uiState, viewModel = viewModel)
        }
      }
    }
  }
}

@Composable
private fun PrideShieldCommandShell(
  uiState: PrideShieldUiState,
  viewModel: PrideShieldViewModel,
) {
  // BackHandler returns from secondary tabs to Command Center, or engages Camouflage on Home
  BackHandler(enabled = uiState.activeTab != ShieldTab.COMMAND_CENTER) {
    viewModel.selectTab(ShieldTab.COMMAND_CENTER)
  }

  val cyberColors = LocalCyberColors.current
  val navSpecs =
    listOf(
      NavTabSpec(
        tab = ShieldTab.COMMAND_CENTER,
        labelRes = R.string.nav_dashboard,
        selectedIcon = Icons.Filled.Dashboard,
        unselectedIcon = Icons.Outlined.Dashboard,
        testTag = "nav_tab_dashboard",
      ),
      NavTabSpec(
        tab = ShieldTab.QUANTUM_VAULT,
        labelRes = R.string.nav_quantum_vault,
        selectedIcon = Icons.Filled.EnhancedEncryption,
        unselectedIcon = Icons.Outlined.EnhancedEncryption,
        testTag = "nav_tab_vault",
      ),
      NavTabSpec(
        tab = ShieldTab.ZERO_TRUST_AI,
        labelRes = R.string.nav_zero_trust,
        selectedIcon = Icons.Filled.Radar,
        unselectedIcon = Icons.Outlined.Radar,
        testTag = "nav_tab_zerotrust",
      ),
      NavTabSpec(
        tab = ShieldTab.CAMOUFLAGE_SETTINGS,
        labelRes = R.string.nav_settings,
        selectedIcon = Icons.Filled.AdminPanelSettings,
        unselectedIcon = Icons.Outlined.AdminPanelSettings,
        testTag = "nav_tab_settings",
      ),
    )

  CyberSecurityGridBackground {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
      val useNavigationRail = maxWidth >= 600.dp

      Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
          if (!useNavigationRail) {
            NavigationBar(
              containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
              tonalElevation = 8.dp,
            ) {
              navSpecs.forEach { spec ->
                val selected = uiState.activeTab == spec.tab
                NavigationBarItem(
                  selected = selected,
                  onClick = { viewModel.selectTab(spec.tab) },
                  icon = {
                    Icon(
                      imageVector = if (selected) spec.selectedIcon else spec.unselectedIcon,
                      contentDescription = stringResource(spec.labelRes),
                    )
                  },
                  label = { Text(stringResource(spec.labelRes)) },
                  colors =
                    NavigationBarItemDefaults.colors(
                      selectedIconColor = Color.Black,
                      selectedTextColor = cyberColors.gridBlue,
                      indicatorColor = cyberColors.gridBlue,
                      unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                      unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    ),
                  modifier = Modifier.testTag(spec.testTag),
                )
              }
            }
          }
        },
      ) { innerPadding ->
        Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
          if (useNavigationRail) {
            NavigationRail(
              containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
              modifier = Modifier.fillMaxHeight(),
            ) {
              navSpecs.forEach { spec ->
                val selected = uiState.activeTab == spec.tab
                NavigationRailItem(
                  selected = selected,
                  onClick = { viewModel.selectTab(spec.tab) },
                  icon = {
                    Icon(
                      imageVector = if (selected) spec.selectedIcon else spec.unselectedIcon,
                      contentDescription = stringResource(spec.labelRes),
                    )
                  },
                  label = { Text(stringResource(spec.labelRes)) },
                  colors =
                    NavigationRailItemDefaults.colors(
                      selectedIconColor = Color.Black,
                      selectedTextColor = cyberColors.gridBlue,
                      indicatorColor = cyberColors.gridBlue,
                      unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                      unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    ),
                  modifier = Modifier.testTag(spec.testTag),
                )
              }
            }
          }

          Box(
            modifier = Modifier.weight(1f).fillMaxHeight(),
            contentAlignment = Alignment.TopCenter,
          ) {
            Column(
              modifier = Modifier.fillMaxSize().widthIn(max = 760.dp),
            ) {
              CyberAlertBanner(
                banner = uiState.statusBanner,
                onDismiss = viewModel::dismissStatusBanner,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
              )

              Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                when (uiState.activeTab) {
                  ShieldTab.COMMAND_CENTER ->
                    CommandDashboardTab(
                      uiState = uiState,
                      onNavigateTab = viewModel::selectTab,
                      onTriggerPanicCamouflage = viewModel::triggerPanicCamouflage,
                    )

                  ShieldTab.QUANTUM_VAULT ->
                    QuantumVaultTab(
                      vaultFiles = uiState.vaultFiles,
                      totalRamBytesWiped = uiState.totalRamBytesWiped,
                      isCryptoBusy = uiState.isCryptoBusy,
                      decryptedPreview = uiState.decryptedPreview,
                      onEncryptPickedFile = viewModel::encryptPickedFile,
                      onEncryptSecretNote = viewModel::encryptSecretNote,
                      onDecryptItem = viewModel::decryptAndPreviewItem,
                      onRetryQuarantineItem = viewModel::retryQuarantinedItem,
                      onShredItem = viewModel::shredVaultEntity,
                      onClosePreview = viewModel::closeDecryptedPreview,
                    )

                  ShieldTab.ZERO_TRUST_AI ->
                    ZeroTrustTab(
                      scanSummary = uiState.zeroTrustSummary,
                      watchlist = uiState.watchlist,
                      isScanning = uiState.isScanningZeroTrust,
                      onTriggerScan = viewModel::triggerZeroTrustScan,
                      onToggleWatchlist = viewModel::toggleWatchlist,
                    )

                  ShieldTab.CAMOUFLAGE_SETTINGS ->
                    SecuritySettingsTab(
                      pureStealthMode = uiState.pureStealthMode,
                      isDefaultCodeActive = uiState.isDefaultCodeActive,
                      onSaveCodes = viewModel::saveSecurityCodes,
                      onTogglePureStealth = viewModel::togglePureStealthMode,
                      onTriggerPanicCamouflage = viewModel::triggerPanicCamouflage,
                      onClearLogs = viewModel::clearAuditLogs,
                    )
                }
              }
            }
          }
        }
      }
    }
  }
}
