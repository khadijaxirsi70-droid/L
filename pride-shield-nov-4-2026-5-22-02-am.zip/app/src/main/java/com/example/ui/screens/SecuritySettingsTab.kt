package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.components.CyberGlassCard
import com.example.ui.components.CyberSemanticPill
import com.example.ui.theme.LocalCyberColors

@Composable
fun SecuritySettingsTab(
  pureStealthMode: Boolean,
  isDefaultCodeActive: Boolean,
  onSaveCodes: (calcCode: String, emergencyPin: String) -> Unit,
  onTogglePureStealth: (Boolean) -> Unit,
  onTriggerPanicCamouflage: () -> Unit,
  onClearLogs: () -> Unit,
) {
  val cyberColors = LocalCyberColors.current

  var newCalcSecret by rememberSaveable { mutableStateOf("2028") }
  var newEmergencyPin by rememberSaveable { mutableStateOf("2028") }

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("security_settings_tab"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1. Secret Camouflage Code & Emergency PIN Configuration
    item {
      CyberGlassCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = cyberColors.gridBlue.copy(alpha = 0.55f),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          CyberSemanticPill(text = "CAMOUFLAGE & PIN VAULT", accentColor = cyberColors.gridBlue)
          CyberSemanticPill(
            text = if (isDefaultCodeActive) "الكود الافتراضي: 2028" else "كود مخصص مشفر",
            accentColor = cyberColors.successYellow,
          )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = stringResource(R.string.settings_title),
          style = MaterialTheme.typography.headlineMedium,
          color = MaterialTheme.colorScheme.onBackground,
        )

        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
          value = newCalcSecret,
          onValueChange = { input -> newCalcSecret = input.filter { it.isDigit() }.take(10) },
          label = { Text(stringResource(R.string.settings_secret_code_label)) },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
          visualTransformation = PasswordVisualTransformation(),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("settings_calc_code_input"),
        )

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
          value = newEmergencyPin,
          onValueChange = { input -> newEmergencyPin = input.filter { it.isDigit() }.take(8) },
          label = { Text(stringResource(R.string.settings_pin_label)) },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
          visualTransformation = PasswordVisualTransformation(),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("settings_emergency_pin_input"),
        )

        Spacer(modifier = Modifier.height(14.dp))
        Button(
          onClick = { onSaveCodes(newCalcSecret, newEmergencyPin) },
          colors =
            ButtonDefaults.buttonColors(
              containerColor = cyberColors.successYellow,
              contentColor = Color.Black,
            ),
          modifier =
            Modifier.fillMaxWidth()
              .height(50.dp)
              .minimumInteractiveComponentSize()
              .testTag("save_security_codes_button"),
        ) {
          Icon(imageVector = Icons.Filled.Key, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.settings_save_codes_btn),
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
          )
        }
      }
    }

    // 2. Pure Stealth Camouflage Toggle
    item {
      CyberGlassCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = cyberColors.gridPurple.copy(alpha = 0.55f),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = stringResource(R.string.settings_stealth_mode_title),
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onBackground,
              fontWeight = FontWeight.Bold,
            )
            Text(
              text = stringResource(R.string.settings_stealth_mode_desc),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Switch(
            checked = pureStealthMode,
            onCheckedChange = onTogglePureStealth,
            colors =
              SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = cyberColors.successYellow,
              ),
            modifier = Modifier.testTag("pure_stealth_mode_switch"),
          )
        }

        Spacer(modifier = Modifier.height(14.dp))
        Button(
          onClick = onTriggerPanicCamouflage,
          colors =
            ButtonDefaults.buttonColors(
              containerColor = cyberColors.warningRed,
              contentColor = Color.White,
            ),
          modifier =
            Modifier.fillMaxWidth()
              .height(48.dp)
              .minimumInteractiveComponentSize()
              .testTag("settings_activate_camouflage_button"),
        ) {
          Icon(imageVector = Icons.Filled.VisibilityOff, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text("إغلاق الخزنة والعودة لواجهة الآلة الحاسبة الآن", fontWeight = FontWeight.Bold)
        }
      }
    }

    // 3. 2028 Error Engineering & Zero-Cloud Architecture Verification Card
    item {
      CyberGlassCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = cyberColors.successYellow.copy(alpha = 0.45f),
      ) {
        Text(
          text = "مصفوفة هندسة الأخطاء والبنية الصفرية (2028 Verified)",
          style = MaterialTheme.typography.titleMedium,
          color = cyberColors.successYellow,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(8.dp))

        val guarantees =
          listOf(
            "عطل الكاميرا أو رفض الصلاحية ← انتقال تلقائي فوري لبروتوكول رمز المرور (PIN).",
            "تعذر التشفير الكمي ← حفظ تلقائي للملف داخل مساحة معزولة خاصة (Isolated Sandbox).",
            "تدمير المفتاح في الذاكرة (RAM) ← مسح ثلاثي المراحل (0xFF → 0xAA → 0x00) في كتلة finally.",
            "استقلالية محلية كاملة ← صفر Firebase وصفر Google Services مع معالجة Try-Catch شاملة.",
          )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          guarantees.forEach { item ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = null,
                tint = cyberColors.successYellow,
                modifier = Modifier.size(18.dp),
              )
              Text(
                text = item,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        OutlinedButton(
          onClick = onClearLogs,
          border = BorderStroke(1.dp, cyberColors.warningRed.copy(alpha = 0.65f)),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = cyberColors.warningRed),
          modifier =
            Modifier.fillMaxWidth()
              .height(48.dp)
              .minimumInteractiveComponentSize()
              .testTag("clear_audit_logs_button"),
        ) {
          Icon(imageVector = Icons.Filled.DeleteSweep, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(stringResource(R.string.settings_clear_logs_btn))
        }
      }
    }
  }
}
