package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// Core Obsidian Black Backgrounds
val CyberPitchBlack = Color(0xFF020307)
val CyberDeepVoid = Color(0xFF070913)
val CyberSurfaceDark = Color(0xFF0C1021)
val CyberSurfaceElevated = Color(0xFF131933)
val CyberSurfaceGlass = Color(0xCC0E1428)

// Glowing Security Grid Accents (Electric Blue & Royal Ultraviolet Purple)
val NeonElectricBlue = Color(0xFF00E5FF)
val NeonDeepBlue = Color(0xFF2979FF)
val NeonUltraviolet = Color(0xFF9D4EDD)
val NeonRoyalPurple = Color(0xFF7C4DFF)
val CyberGridLineBlue = Color(0x4400E5FF)
val CyberGridLinePurple = Color(0x449D4EDD)

// Mandatory Semantic Accents: Fiery Red for Warnings & Cyber Yellow for Successes
val FieryWarningRed = Color(0xFFFF2A3C)
val FieryRedBright = Color(0xFFFF5252)
val FieryRedContainer = Color(0xFF36070E)

val CyberSuccessYellow = Color(0xFFFFD600)
val CyberYellowBright = Color(0xFFFFEA00)
val CyberYellowContainer = Color(0xFF332900)

// Neutral Text & Borders
val CyberTextPrimary = Color(0xFFF2F6FF)
val CyberTextSecondary = Color(0xFF9AA8C7)
val CyberTextMuted = Color(0xFF5E6C8C)
val CyberBorderSubtle = Color(0xFF1F2B4D)

// Calculator Camouflage Palette (Subtle Sleek Charcoal so it looks 100% like a real utility calculator)
val CalcBackground = Color(0xFF090B10)
val CalcDisplaySurface = Color(0xFF11151F)
val CalcKeySurface = Color(0xFF181D2A)
val CalcOperatorSurface = Color(0xFF1E2742)
val CalcEqualsAccent = Color(0xFF2979FF)

@Immutable
data class CyberExtendedColors(
  val gridBlue: Color = NeonElectricBlue,
  val gridPurple: Color = NeonUltraviolet,
  val warningRed: Color = FieryWarningRed,
  val warningRedContainer: Color = FieryRedContainer,
  val successYellow: Color = CyberSuccessYellow,
  val successYellowContainer: Color = CyberYellowContainer,
  val surfaceGlass: Color = CyberSurfaceGlass,
  val borderSubtle: Color = CyberBorderSubtle,
  val calcBackground: Color = CalcBackground,
  val calcDisplay: Color = CalcDisplaySurface,
  val calcKey: Color = CalcKeySurface,
  val calcOperator: Color = CalcOperatorSurface,
  val calcEquals: Color = CalcEqualsAccent,
)

val LocalCyberColors = staticCompositionLocalOf { CyberExtendedColors() }
