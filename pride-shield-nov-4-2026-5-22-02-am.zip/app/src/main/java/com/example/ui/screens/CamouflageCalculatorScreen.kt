package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.CalcHistoryEntry
import com.example.ui.theme.CyberMonoFontFamily
import com.example.ui.theme.LocalCyberColors

@Composable
fun CamouflageCalculatorScreen(
  expression: String,
  resultPreview: String,
  history: List<CalcHistoryEntry>,
  showFirstRunSetupHint: Boolean,
  isDefaultCodeActive: Boolean,
  onKeyPress: (String) -> Unit,
  onEqualsPress: () -> Unit,
  onClearHistory: () -> Unit,
  onDismissHint: () -> Unit,
) {
  val cyberColors = LocalCyberColors.current
  var showHistoryDrawer by rememberSaveable { mutableStateOf(false) }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(cyberColors.calcBackground)
        .windowInsetsPadding(WindowInsets.safeDrawing)
        .testTag("camouflage_calculator_screen"),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier.fillMaxSize()
          .widthIn(max = 520.dp)
          .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      // Top Utility Header + Optional Dismissible First-Run Setup Hint
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Calculate,
              contentDescription = stringResource(R.string.calc_header_title),
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(22.dp),
            )
            Text(
              text = stringResource(R.string.calc_header_title),
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          IconButton(
            onClick = { showHistoryDrawer = !showHistoryDrawer },
            modifier = Modifier.testTag("calc_toggle_history_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.History,
              contentDescription = stringResource(R.string.calc_clear_history),
              tint =
                if (showHistoryDrawer) cyberColors.calcEquals
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }

        AnimatedVisibility(visible = showFirstRunSetupHint && isDefaultCodeActive) {
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(cyberColors.calcDisplay)
                .border(1.dp, cyberColors.borderSubtle, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .testTag("calc_first_run_hint_banner"),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = stringResource(R.string.calc_first_run_hint),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.weight(1f),
            )
            IconButton(
              onClick = onDismissHint,
              modifier = Modifier.size(36.dp).testTag("calc_dismiss_hint_button"),
            ) {
              Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = stringResource(R.string.cd_calc_hint_dismiss),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp),
              )
            }
          }
        }

        AnimatedVisibility(visible = showHistoryDrawer) {
          Column(
            modifier =
              Modifier.fillMaxWidth()
                .heightIn(max = 140.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(cyberColors.calcDisplay)
                .border(1.dp, cyberColors.borderSubtle, RoundedCornerShape(14.dp))
                .padding(12.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "السجل الحسابي (${history.size})",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              if (history.isNotEmpty()) {
                TextButton(
                  onClick = onClearHistory,
                  modifier = Modifier.testTag("calc_clear_history_button"),
                ) {
                  Text(
                    text = stringResource(R.string.calc_clear_history),
                    style = MaterialTheme.typography.labelSmall,
                  )
                }
              }
            }
            if (history.isEmpty()) {
              Text(
                text = "لا توجد عمليات سابقة",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            } else {
              LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(history) { item ->
                  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Text(
                      text = "${item.expression} = ${item.result}",
                      fontFamily = CyberMonoFontFamily,
                      fontSize = 13.sp,
                      color = MaterialTheme.colorScheme.onSurface,
                      textAlign = TextAlign.End,
                      modifier = Modifier.fillMaxWidth(),
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Calculator Display Panel (Forced LTR for mathematical precision)
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(
          modifier =
            Modifier.fillMaxWidth()
              .weight(1f, fill = false)
              .padding(vertical = 12.dp)
              .clip(RoundedCornerShape(22.dp))
              .background(cyberColors.calcDisplay)
              .border(1.dp, cyberColors.borderSubtle, RoundedCornerShape(22.dp))
              .padding(horizontal = 20.dp, vertical = 22.dp)
              .testTag("calc_display_panel"),
          horizontalAlignment = Alignment.End,
          verticalArrangement = Arrangement.Bottom,
        ) {
          Text(
            text = expression.ifEmpty { "0" },
            fontFamily = CyberMonoFontFamily,
            fontSize = if (expression.length > 14) 24.sp else 34.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.End,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth().testTag("calc_expression_text"),
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "= $resultPreview",
            fontFamily = CyberMonoFontFamily,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.End,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth().testTag("calc_result_preview_text"),
          )
        }
      }

      // Standard 5x4 Keypad Grid (Forced LTR so keypad layout matches universal calculators)
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        val rows =
          listOf(
            listOf("C", "±", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "⌫", "="),
          )

        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          rows.forEach { rowKeys ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              rowKeys.forEach { key ->
                val isOperator = key in setOf("÷", "×", "−", "+", "%", "±")
                val isClear = key == "C"
                val isEquals = key == "="

                val bg =
                  when {
                    isEquals -> cyberColors.calcEquals
                    isClear -> cyberColors.warningRed.copy(alpha = 0.2f)
                    isOperator -> cyberColors.calcOperator
                    else -> cyberColors.calcKey
                  }
                val contentCol =
                  when {
                    isEquals -> Color.White
                    isClear -> cyberColors.warningRed
                    isOperator -> cyberColors.gridBlue
                    else -> MaterialTheme.colorScheme.onBackground
                  }

                CalculatorKeyButton(
                  keySymbol = key,
                  backgroundColor = bg,
                  contentColor = contentCol,
                  onClick = {
                    if (isEquals) onEqualsPress() else onKeyPress(key)
                  },
                  modifier = Modifier.weight(1f),
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun CalculatorKeyButton(
  keySymbol: String,
  backgroundColor: Color,
  contentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val safeTag =
    when (keySymbol) {
      "=" -> "calc_key_equals"
      "C" -> "calc_key_clear"
      "⌫" -> "calc_key_backspace"
      "+" -> "calc_key_plus"
      "−" -> "calc_key_minus"
      "×" -> "calc_key_multiply"
      "÷" -> "calc_key_divide"
      "." -> "calc_key_dot"
      "%" -> "calc_key_percent"
      "±" -> "calc_key_sign"
      else -> "calc_key_$keySymbol"
    }

  Surface(
    modifier =
      modifier
        .height(64.dp)
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(18.dp))
        .clickable(onClick = onClick)
        .testTag(safeTag),
    color = backgroundColor,
    shape = RoundedCornerShape(18.dp),
  ) {
    Box(contentAlignment = Alignment.Center) {
      if (keySymbol == "⌫") {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.Backspace,
          contentDescription = stringResource(R.string.cd_calc_backspace),
          tint = contentColor,
          modifier = Modifier.size(24.dp),
        )
      } else {
        Text(
          text = keySymbol,
          fontFamily = CyberMonoFontFamily,
          fontSize = 22.sp,
          fontWeight = FontWeight.Bold,
          color = contentColor,
        )
      }
    }
  }
}
