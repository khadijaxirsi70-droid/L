package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.ZeroTrustWatchEntity
import com.example.security.AppBehaviorReport
import com.example.security.OsPostureSignal
import com.example.security.ZeroTrustRiskLevel
import com.example.security.ZeroTrustScanSummary
import com.example.ui.components.CyberGlassCard
import com.example.ui.components.CyberSemanticPill
import com.example.ui.theme.CyberMonoFontFamily
import com.example.ui.theme.LocalCyberColors

private enum class ZeroTrustFilter {
  ALL,
  CRITICAL,
  ELEVATED,
  WATCHLIST,
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ZeroTrustTab(
  scanSummary: ZeroTrustScanSummary?,
  watchlist: List<ZeroTrustWatchEntity>,
  isScanning: Boolean,
  onTriggerScan: () -> Unit,
  onToggleWatchlist: (AppBehaviorReport, Boolean) -> Unit,
) {
  val cyberColors = LocalCyberColors.current
  var activeFilter by rememberSaveable { mutableStateOf(ZeroTrustFilter.ALL) }
  val watchedSet = watchlist.map { it.packageName }.toSet()

  val filteredApps =
    when (activeFilter) {
      ZeroTrustFilter.ALL -> scanSummary?.appReports.orEmpty()
      ZeroTrustFilter.CRITICAL ->
        scanSummary?.appReports.orEmpty().filter {
          it.riskLevel == ZeroTrustRiskLevel.CRITICAL_SPYWARE
        }
      ZeroTrustFilter.ELEVATED ->
        scanSummary?.appReports.orEmpty().filter {
          it.riskLevel == ZeroTrustRiskLevel.ELEVATED_WATCH
        }
      ZeroTrustFilter.WATCHLIST ->
        scanSummary?.appReports.orEmpty().filter { it.packageName in watchedSet }
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("zero_trust_tab"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    // 1. Header & Deep Behavioral Scan Trigger
    item {
      CyberGlassCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = cyberColors.gridPurple.copy(alpha = 0.65f),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          CyberSemanticPill(text = "ZERO-TRUST AI ENGINE", accentColor = cyberColors.gridPurple)
          val score = scanSummary?.overallTrustIndex ?: 95
          CyberSemanticPill(
            text = "مؤشر الثقة: $score/100",
            accentColor =
              if (score >= 80) cyberColors.successYellow else cyberColors.warningRed,
          )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = stringResource(R.string.zt_title),
          style = MaterialTheme.typography.headlineMedium,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
          text = stringResource(R.string.zt_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(modifier = Modifier.height(12.dp))
        Button(
          onClick = onTriggerScan,
          enabled = !isScanning,
          colors =
            ButtonDefaults.buttonColors(
              containerColor = cyberColors.gridBlue,
              contentColor = Color.Black,
            ),
          modifier =
            Modifier.fillMaxWidth()
              .height(50.dp)
              .minimumInteractiveComponentSize()
              .testTag("run_zero_trust_scan_button"),
        ) {
          if (isScanning) {
            CircularProgressIndicator(
              modifier = Modifier.size(20.dp),
              strokeWidth = 2.dp,
              color = Color.Black,
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("جاري تحليل الصلاحيات وسلوك الحزم...", fontWeight = FontWeight.Bold)
          } else {
            Icon(imageVector = Icons.Filled.Radar, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.zt_btn_rescan),
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.titleMedium,
            )
          }
        }
      }
    }

    // 2. OS & Kernel Telemetry Signals
    if (!scanSummary?.osSignals.isNullOrEmpty()) {
      item {
        Text(
          text = stringResource(R.string.zt_os_posture_title),
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
      }

      items(scanSummary?.osSignals.orEmpty(), key = { "os_${it.id}" }) { signal ->
        OsSignalRow(signal = signal)
      }
    }

    // 3. App Behavioral Spyware Detection Matrix & Filter Chips
    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = stringResource(R.string.zt_apps_title),
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )

        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          FilterChip(
            selected = activeFilter == ZeroTrustFilter.ALL,
            onClick = { activeFilter = ZeroTrustFilter.ALL },
            label = { Text("الكل (${scanSummary?.appReports?.size ?: 0})") },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = cyberColors.gridBlue.copy(alpha = 0.25f),
                selectedLabelColor = cyberColors.gridBlue,
              ),
            modifier = Modifier.testTag("zt_filter_all"),
          )
          FilterChip(
            selected = activeFilter == ZeroTrustFilter.CRITICAL,
            onClick = { activeFilter = ZeroTrustFilter.CRITICAL },
            label = { Text("تهديد تجسس (${scanSummary?.criticalCount ?: 0})") },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = cyberColors.warningRed.copy(alpha = 0.25f),
                selectedLabelColor = cyberColors.warningRed,
              ),
            modifier = Modifier.testTag("zt_filter_critical"),
          )
          FilterChip(
            selected = activeFilter == ZeroTrustFilter.ELEVATED,
            onClick = { activeFilter = ZeroTrustFilter.ELEVATED },
            label = { Text("قيد الرصد (${scanSummary?.elevatedCount ?: 0})") },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = cyberColors.gridPurple.copy(alpha = 0.25f),
                selectedLabelColor = cyberColors.gridPurple,
              ),
            modifier = Modifier.testTag("zt_filter_elevated"),
          )
          FilterChip(
            selected = activeFilter == ZeroTrustFilter.WATCHLIST,
            onClick = { activeFilter = ZeroTrustFilter.WATCHLIST },
            label = { Text("المعزولة رقابياً (${watchlist.size})") },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = cyberColors.successYellow.copy(alpha = 0.25f),
                selectedLabelColor = cyberColors.successYellow,
              ),
            modifier = Modifier.testTag("zt_filter_watchlist"),
          )
        }
      }
    }

    if (filteredApps.isEmpty()) {
      item {
        CyberGlassCard(modifier = Modifier.fillMaxWidth()) {
          Text(
            text =
              if (isScanning) "جاري استخراج مصفوفة السلوك..."
              else "لا توجد حزم مطابقة لهذا الفلتر — جميع المؤشرات تحت السيطرة.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    } else {
      items(filteredApps, key = { it.packageName }) { appReport ->
        AppBehaviorCard(
          report = appReport,
          isWatched = appReport.packageName in watchedSet,
          onToggleWatch = {
            onToggleWatchlist(appReport, appReport.packageName in watchedSet)
          },
        )
      }
    }
  }
}

@Composable
private fun OsSignalRow(signal: OsPostureSignal) {
  val cyberColors = LocalCyberColors.current
  val accent = if (signal.isSafe) cyberColors.successYellow else cyberColors.warningRed

  CyberGlassCard(
    modifier = Modifier.fillMaxWidth(),
    borderColor = accent.copy(alpha = 0.45f),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Icon(
        imageVector = if (signal.isSafe) Icons.Filled.CheckCircle else Icons.Filled.GppBad,
        contentDescription = signal.title,
        tint = accent,
        modifier = Modifier.size(24.dp),
      )
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = signal.title,
          style = MaterialTheme.typography.titleSmall,
          color = accent,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = signal.statusText,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AppBehaviorCard(
  report: AppBehaviorReport,
  isWatched: Boolean,
  onToggleWatch: () -> Unit,
) {
  val cyberColors = LocalCyberColors.current
  var expanded by rememberSaveable { mutableStateOf(false) }

  val accent =
    when (report.riskLevel) {
      ZeroTrustRiskLevel.CRITICAL_SPYWARE -> cyberColors.warningRed
      ZeroTrustRiskLevel.ELEVATED_WATCH -> cyberColors.gridPurple
      ZeroTrustRiskLevel.VERIFIED_TRUSTED -> cyberColors.successYellow
    }

  val badgeLabel =
    when (report.riskLevel) {
      ZeroTrustRiskLevel.CRITICAL_SPYWARE -> "خطر تجسس (${report.riskScore}%)"
      ZeroTrustRiskLevel.ELEVATED_WATCH -> "رصد سلوكي (${report.riskScore}%)"
      ZeroTrustRiskLevel.VERIFIED_TRUSTED -> "موثوق (${report.riskScore}%)"
    }

  CyberGlassCard(
    modifier =
      Modifier.fillMaxWidth()
        .clickable { expanded = !expanded }
        .testTag("zt_app_card_${report.packageName}"),
    borderColor = if (isWatched) cyberColors.warningRed else accent.copy(alpha = 0.45f),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = report.appName,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onBackground,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = report.packageName,
          fontFamily = CyberMonoFontFamily,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      CyberSemanticPill(text = badgeLabel, accentColor = accent)
      Icon(
        imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
        contentDescription = "تفاصيل السلوك",
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }

    Spacer(modifier = Modifier.height(8.dp))
    LinearProgressIndicator(
      progress = { (report.riskScore / 100f).coerceIn(0.04f, 1f) },
      color = accent,
      trackColor = MaterialTheme.colorScheme.surfaceVariant,
      modifier = Modifier.fillMaxWidth().height(6.dp),
    )

    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = report.behaviorSummary,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurface,
    )

    AnimatedVisibility(visible = expanded) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Text(
          text =
            "مكونات الخلفية النشطة: ${report.backgroundComponentsCount}  |  نوع الحزمة: ${if (report.isSystemApp) "نواة/نظام" else "تطبيق مستخدم"}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (report.sensitivePermissions.isNotEmpty()) {
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            report.sensitivePermissions.forEach { permArabic ->
              CyberSemanticPill(text = permArabic, accentColor = accent)
            }
          }
        }

        OutlinedButton(
          onClick = onToggleWatch,
          border =
            BorderStroke(
              1.dp,
              if (isWatched) cyberColors.successYellow else cyberColors.warningRed,
            ),
          colors =
            ButtonDefaults.outlinedButtonColors(
              contentColor = if (isWatched) cyberColors.successYellow else cyberColors.warningRed
            ),
          modifier =
            Modifier.fillMaxWidth()
              .minimumInteractiveComponentSize()
              .testTag("toggle_watch_${report.packageName}"),
        ) {
          Icon(
            imageVector = if (isWatched) Icons.Filled.Security else Icons.Filled.Policy,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text =
              if (isWatched) "رفع العزل الرقابي عن الحزمة"
              else "إدراج في قائمة العزل والمراقبة الصفرية",
            fontWeight = FontWeight.Bold,
          )
        }
      }
    }
  }
}
