package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.AuditSeverity
import com.example.data.local.SecurityAuditEntity
import com.example.ui.PrideShieldUiState
import com.example.ui.ShieldTab
import com.example.ui.components.CyberGlassCard
import com.example.ui.components.CyberSemanticPill
import com.example.ui.theme.CyberMonoFontFamily
import com.example.ui.theme.LocalCyberColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CommandDashboardTab(
  uiState: PrideShieldUiState,
  onNavigateTab: (ShieldTab) -> Unit,
  onTriggerPanicCamouflage: () -> Unit,
) {
  val cyberColors = LocalCyberColors.current
  val encryptedCount = uiState.vaultFiles.count { it.isEncrypted && !it.isQuarantined }
  val quarantinedCount = uiState.vaultFiles.count { it.isQuarantined }
  val trustIndex = uiState.zeroTrustSummary?.overallTrustIndex ?: 96

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("command_dashboard_tab"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1. Holographic Hero Banner with Panic Camouflage Action
    item {
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .height(205.dp)
            .clip(MaterialTheme.shapes.large)
            .border(1.5.dp, cyberColors.gridBlue.copy(alpha = 0.55f), MaterialTheme.shapes.large)
      ) {
        Image(
          painter = painterResource(id = R.drawable.img_cyber_shield_hero),
          contentDescription = stringResource(R.string.cd_hero_banner),
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )

        Box(
          modifier =
            Modifier.fillMaxSize()
              .background(
                Brush.verticalGradient(
                  colors =
                    listOf(
                      Color.Black.copy(alpha = 0.35f),
                      Color.Black.copy(alpha = 0.85f),
                    )
                )
              )
              .padding(18.dp)
        ) {
          Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              CyberSemanticPill(
                text = "QUANTUM DEFENSE ACTIVE",
                accentColor = cyberColors.successYellow,
              )

              Button(
                onClick = onTriggerPanicCamouflage,
                colors =
                  ButtonDefaults.buttonColors(
                    containerColor = cyberColors.warningRed,
                    contentColor = Color.White,
                  ),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier =
                  Modifier.minimumInteractiveComponentSize().testTag("panic_camouflage_button"),
              ) {
                Icon(
                  imageVector = Icons.Filled.VisibilityOff,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = stringResource(R.string.dash_panic_camouflage),
                  style = MaterialTheme.typography.labelLarge,
                )
              }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(
                text = stringResource(R.string.dash_hero_title),
                style = MaterialTheme.typography.headlineMedium,
                color = cyberColors.gridBlue,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = stringResource(R.string.dash_hero_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
              )
            }
          }
        }
      }
    }

    // 2. 2x2 Tactical Telemetry Grid
    item {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          MetricSummaryCard(
            title = stringResource(R.string.dash_metric_encrypted),
            value = "$encryptedCount",
            badge = "AES-256-GCM",
            icon = Icons.Filled.EnhancedEncryption,
            accentColor = cyberColors.successYellow,
            onClick = { onNavigateTab(ShieldTab.QUANTUM_VAULT) },
            modifier = Modifier.weight(1f).testTag("metric_card_encrypted"),
          )

          MetricSummaryCard(
            title = stringResource(R.string.dash_metric_quarantine),
            value = "$quarantinedCount",
            badge = if (quarantinedCount > 0) "عزل نشط" else "سليم 100%",
            icon = Icons.Filled.GppBad,
            accentColor =
              if (quarantinedCount > 0) cyberColors.warningRed else cyberColors.gridPurple,
            onClick = { onNavigateTab(ShieldTab.QUANTUM_VAULT) },
            modifier = Modifier.weight(1f).testTag("metric_card_quarantine"),
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          MetricSummaryCard(
            title = stringResource(R.string.dash_metric_ram_wiped),
            value = "${uiState.totalRamBytesWiped} B",
            badge = "0xFF→0xAA→0x00",
            icon = Icons.Filled.Memory,
            accentColor = cyberColors.gridBlue,
            onClick = { onNavigateTab(ShieldTab.QUANTUM_VAULT) },
            modifier = Modifier.weight(1f).testTag("metric_card_ram_wiped"),
          )

          MetricSummaryCard(
            title = stringResource(R.string.dash_metric_zerotrust),
            value = "$trustIndex%",
            badge =
              if ((uiState.zeroTrustSummary?.criticalCount ?: 0) > 0) "تنبيه سلوكي"
              else "موثوق",
            icon = Icons.Filled.Radar,
            accentColor =
              if ((uiState.zeroTrustSummary?.criticalCount ?: 0) > 0) cyberColors.warningRed
              else cyberColors.successYellow,
            onClick = { onNavigateTab(ShieldTab.ZERO_TRUST_AI) },
            modifier = Modifier.weight(1f).testTag("metric_card_zero_trust"),
          )
        }
      }
    }

    // 3. Security Audit & Error-Engineering Stream Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Shield,
            contentDescription = null,
            tint = cyberColors.gridPurple,
          )
          Text(
            text = stringResource(R.string.dash_audit_title),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
          )
        }
        CyberSemanticPill(
          text = "${uiState.securityAudits.size} حدث",
          accentColor = cyberColors.gridBlue,
        )
      }
    }

    if (uiState.securityAudits.isEmpty()) {
      item {
        CyberGlassCard(modifier = Modifier.fillMaxWidth()) {
          Text(
            text = stringResource(R.string.dash_audit_empty),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    } else {
      items(uiState.securityAudits.take(25), key = { it.id }) { audit ->
        AuditLogItemCard(audit = audit)
      }
    }
  }
}

@Composable
private fun MetricSummaryCard(
  title: String,
  value: String,
  badge: String,
  icon: ImageVector,
  accentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  CyberGlassCard(
    modifier = modifier.clip(MaterialTheme.shapes.medium).clickable(onClick = onClick),
    borderColor = accentColor.copy(alpha = 0.45f),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier =
          Modifier.size(38.dp)
            .clip(CircleShape)
            .background(accentColor.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = accentColor,
          modifier = Modifier.size(20.dp),
        )
      }
      CyberSemanticPill(text = badge, accentColor = accentColor)
    }

    Spacer(modifier = Modifier.height(12.dp))
    Text(
      text = value,
      fontFamily = CyberMonoFontFamily,
      style = MaterialTheme.typography.headlineMedium,
      color = accentColor,
      fontWeight = FontWeight.Bold,
    )
    Text(
      text = title,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
  }
}

@Composable
private fun AuditLogItemCard(audit: SecurityAuditEntity) {
  val cyberColors = LocalCyberColors.current
  val accent =
    when (audit.severity) {
      AuditSeverity.WARNING_RED.name -> cyberColors.warningRed
      AuditSeverity.SUCCESS_YELLOW.name -> cyberColors.successYellow
      else -> cyberColors.gridBlue
    }

  val formattedTime =
    try {
      SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(audit.timestamp))
    } catch (_: Exception) {
      "--:--"
    }

  CyberGlassCard(
    modifier = Modifier.fillMaxWidth(),
    borderColor = accent.copy(alpha = 0.4f),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      CyberSemanticPill(text = audit.category, accentColor = accent)
      Text(
        text = formattedTime,
        fontFamily = CyberMonoFontFamily,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = audit.title,
      style = MaterialTheme.typography.titleSmall,
      color = accent,
      fontWeight = FontWeight.Bold,
    )
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = audit.details,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurface,
    )
  }
}
