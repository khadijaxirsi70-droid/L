package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val PrideShieldColorScheme =
  darkColorScheme(
    primary = NeonElectricBlue,
    onPrimary = CyberPitchBlack,
    primaryContainer = CyberSurfaceElevated,
    onPrimaryContainer = NeonElectricBlue,
    secondary = NeonUltraviolet,
    onSecondary = CyberTextPrimary,
    secondaryContainer = CyberSurfaceElevated,
    onSecondaryContainer = NeonUltraviolet,
    tertiary = CyberSuccessYellow,
    onTertiary = CyberPitchBlack,
    tertiaryContainer = CyberYellowContainer,
    onTertiaryContainer = CyberSuccessYellow,
    error = FieryWarningRed,
    onError = CyberTextPrimary,
    errorContainer = FieryRedContainer,
    onErrorContainer = FieryRedBright,
    background = CyberPitchBlack,
    onBackground = CyberTextPrimary,
    surface = CyberDeepVoid,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberSurfaceDark,
    onSurfaceVariant = CyberTextSecondary,
    outline = CyberBorderSubtle,
    outlineVariant = CyberGridLinePurple,
  )

val PrideShieldShapes =
  Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
  )

@Composable
fun PrideShieldTheme(content: @Composable () -> Unit) {
  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      try {
        val window = (view.context as? Activity)?.window
        if (window != null) {
          WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
          WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
      } catch (_: Exception) {
        // Safely ignore window styling failures in preview/headless environments
      }
    }
  }

  CompositionLocalProvider(LocalCyberColors provides CyberExtendedColors()) {
    MaterialTheme(
      colorScheme = PrideShieldColorScheme,
      typography = PrideShieldTypography,
      shapes = PrideShieldShapes,
      content = content,
    )
  }
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  PrideShieldTheme(content = content)
}
