package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PrideShieldRepository
import com.example.data.local.AuditSeverity
import com.example.data.local.PrideShieldDatabase
import com.example.data.local.SecurityAuditEntity
import com.example.data.local.VaultFileEntity
import com.example.data.local.ZeroTrustWatchEntity
import com.example.data.preferences.SecurityPreferencesRepository
import com.example.security.AppBehaviorReport
import com.example.security.CalcEvaluationResult
import com.example.security.CamouflageCalculatorEngine
import com.example.security.DecryptionOutcome
import com.example.security.EncryptionOutcome
import com.example.security.QuantumVaultCryptoEngine
import com.example.security.RamWipeReport
import com.example.security.ZeroTrustBehavioralEngine
import com.example.security.ZeroTrustScanSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class RootGateState {
  CAMOUFLAGE_CALCULATOR,
  DEEPFAKE_BIOMETRIC_AUTH,
  PRIDE_SHIELD_UNLOCKED,
}

enum class AuthSubMode {
  CAMERA_LIVENESS,
  EMERGENCY_PIN_FALLBACK,
}

enum class ShieldTab {
  COMMAND_CENTER,
  QUANTUM_VAULT,
  ZERO_TRUST_AI,
  CAMOUFLAGE_SETTINGS,
}

data class CalcHistoryEntry(val expression: String, val result: String)

data class DecryptedPreviewDialogState(
  val fileName: String,
  val previewText: String,
  val sha256Digest: String,
  val ramWipeReport: RamWipeReport,
)

data class StatusBannerMessage(
  val title: String,
  val subtitle: String,
  val isWarningRed: Boolean,
  val isSuccessYellow: Boolean,
)

private data class InternalSessionState(
  val gateState: RootGateState = RootGateState.CAMOUFLAGE_CALCULATOR,
  val authSubMode: AuthSubMode = AuthSubMode.CAMERA_LIVENESS,
  val cameraFallbackReason: String = "",
  val pinAuthError: String = "",
  val activeTab: ShieldTab = ShieldTab.COMMAND_CENTER,
  val calcInput: String = "",
  val calcResultPreview: String = "0",
  val calcHistory: List<CalcHistoryEntry> = emptyList(),
  val zeroTrustSummary: ZeroTrustScanSummary? = null,
  val isScanningZeroTrust: Boolean = false,
  val isCryptoBusy: Boolean = false,
  val statusBanner: StatusBannerMessage? = null,
  val decryptedPreview: DecryptedPreviewDialogState? = null,
)

data class PrideShieldUiState(
  val gateState: RootGateState = RootGateState.CAMOUFLAGE_CALCULATOR,
  val authSubMode: AuthSubMode = AuthSubMode.CAMERA_LIVENESS,
  val cameraFallbackReason: String = "",
  val pinAuthError: String = "",
  val activeTab: ShieldTab = ShieldTab.COMMAND_CENTER,
  val calcInput: String = "",
  val calcResultPreview: String = "0",
  val calcHistory: List<CalcHistoryEntry> = emptyList(),
  val showCalculatorSetupHint: Boolean = true,
  val pureStealthMode: Boolean = false,
  val isDefaultCodeActive: Boolean = true,
  val totalRamBytesWiped: Long = 0L,
  val vaultFiles: List<VaultFileEntity> = emptyList(),
  val securityAudits: List<SecurityAuditEntity> = emptyList(),
  val watchlist: List<ZeroTrustWatchEntity> = emptyList(),
  val zeroTrustSummary: ZeroTrustScanSummary? = null,
  val isScanningZeroTrust: Boolean = false,
  val isCryptoBusy: Boolean = false,
  val statusBanner: StatusBannerMessage? = null,
  val decryptedPreview: DecryptedPreviewDialogState? = null,
)

class PrideShieldViewModel(application: Application) : AndroidViewModel(application) {

  private val repository: PrideShieldRepository by lazy {
    val ctx = application.applicationContext
    val db = PrideShieldDatabase.getInstance(ctx)
    PrideShieldRepository(
      appContext = ctx,
      dao = db.prideShieldDao(),
      preferencesRepository = SecurityPreferencesRepository(ctx),
      cryptoEngine = QuantumVaultCryptoEngine(ctx),
      zeroTrustEngine = ZeroTrustBehavioralEngine(ctx),
    )
  }

  private val sessionFlow = MutableStateFlow(InternalSessionState())

  val uiState: StateFlow<PrideShieldUiState> =
    combine(
        sessionFlow,
        repository.preferencesFlow,
        repository.vaultFilesFlow,
        repository.securityAuditsFlow,
        repository.watchlistFlow,
      ) { session, prefs, vaultFiles, audits, watchlist ->
        PrideShieldUiState(
          gateState = session.gateState,
          authSubMode = session.authSubMode,
          cameraFallbackReason = session.cameraFallbackReason,
          pinAuthError = session.pinAuthError,
          activeTab = session.activeTab,
          calcInput = session.calcInput,
          calcResultPreview = session.calcResultPreview,
          calcHistory = session.calcHistory,
          showCalculatorSetupHint = !prefs.pureStealthMode && !prefs.onboardingHintDismissed,
          pureStealthMode = prefs.pureStealthMode,
          isDefaultCodeActive = prefs.isDefaultCodeActive,
          totalRamBytesWiped = prefs.totalRamBytesWiped,
          vaultFiles = vaultFiles,
          securityAudits = audits,
          watchlist = watchlist,
          zeroTrustSummary = session.zeroTrustSummary,
          isScanningZeroTrust = session.isScanningZeroTrust,
          isCryptoBusy = session.isCryptoBusy,
          statusBanner = session.statusBanner,
          decryptedPreview = session.decryptedPreview,
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = PrideShieldUiState(),
      )

  // --- Calculator Camouflage Logic ---

  fun onCalculatorKeyPress(symbol: String) {
    try {
      sessionFlow.update { current ->
        val nextExpr =
          when (symbol) {
            "C" -> ""
            "⌫" -> if (current.calcInput.isNotEmpty()) current.calcInput.dropLast(1) else ""
            "±" -> toggleSign(current.calcInput)
            else -> {
              if (current.calcInput.length >= 28) current.calcInput
              else appendCalculatorSymbol(current.calcInput, symbol)
            }
          }

        val livePreview =
          if (nextExpr.isBlank()) {
            "0"
          } else {
            when (val res = CamouflageCalculatorEngine.evaluateExpression(nextExpr)) {
              is CalcEvaluationResult.Success -> res.formattedValue
              is CalcEvaluationResult.Error -> current.calcResultPreview
            }
          }

        current.copy(calcInput = nextExpr, calcResultPreview = livePreview)
      }
    } catch (_: Exception) {
      sessionFlow.update { it.copy(calcInput = "", calcResultPreview = "0") }
    }
  }

  fun onCalculatorEqualsPressed() {
    val rawExpression = sessionFlow.value.calcInput.trim()
    if (rawExpression.isEmpty()) return

    viewModelScope.launch {
      try {
        // Check if raw numeric sequence matches Secret Code!
        val digitsOnlyCandidate = rawExpression.trim()
        val isSecretMatch = repository.verifyCalculatorSecretCode(digitsOnlyCandidate)
        if (isSecretMatch) {
          repository.logSecurityEvent(
            category = "CAMOUFLAGE-GATE",
            severity = AuditSeverity.INFO_BLUE,
            title = "تم فك شفرة بوابة التمويه بنجاح",
            details = "تمت مطابقة الكود السري على الآلة الحاسبة — الانتقال إلى كاشف التزييف العميق.",
          )
          sessionFlow.update {
            it.copy(
              calcInput = "",
              calcResultPreview = "0",
              gateState = RootGateState.DEEPFAKE_BIOMETRIC_AUTH,
              authSubMode = AuthSubMode.CAMERA_LIVENESS,
              cameraFallbackReason = "",
              pinAuthError = "",
            )
          }
          return@launch
        }

        // Standard arithmetic calculation
        when (val eval = CamouflageCalculatorEngine.evaluateExpression(rawExpression)) {
          is CalcEvaluationResult.Success -> {
            sessionFlow.update { state ->
              val updatedHistory =
                (listOf(CalcHistoryEntry(rawExpression, eval.formattedValue)) + state.calcHistory)
                  .take(12)
              state.copy(
                calcInput = eval.formattedValue,
                calcResultPreview = eval.formattedValue,
                calcHistory = updatedHistory,
              )
            }
          }
          is CalcEvaluationResult.Error -> {
            sessionFlow.update { state -> state.copy(calcResultPreview = eval.errorArabic) }
          }
        }
      } catch (_: Exception) {
        sessionFlow.update { it.copy(calcResultPreview = "عملية غير صالحة") }
      }
    }
  }

  fun clearCalculatorHistory() {
    sessionFlow.update { it.copy(calcHistory = emptyList()) }
  }

  fun dismissCalculatorOnboardingHint() {
    viewModelScope.launch { repository.dismissCalculatorOnboardingHint() }
  }

  // --- Deepfake Biometric Liveness & Camera Fallback to PIN ---

  fun onCameraHardwareOrPermissionFailed(reasonArabic: String) {
    viewModelScope.launch {
      try {
        repository.logSecurityEvent(
          category = "CAMERA-FALLBACK",
          severity = AuditSeverity.WARNING_RED,
          title = "فشل الكاميرا — تفعيل تلقائي لبروتوكول الطوارئ (PIN)",
          details = reasonArabic,
        )
      } catch (_: Exception) {}
      sessionFlow.update {
        it.copy(
          authSubMode = AuthSubMode.EMERGENCY_PIN_FALLBACK,
          cameraFallbackReason = reasonArabic,
          pinAuthError = "",
        )
      }
    }
  }

  fun switchToCameraLivenessMode() {
    sessionFlow.update {
      it.copy(
        authSubMode = AuthSubMode.CAMERA_LIVENESS,
        cameraFallbackReason = "",
        pinAuthError = "",
      )
    }
  }

  fun onLivenessVerifiedSuccess() {
    if (sessionFlow.value.gateState == RootGateState.PRIDE_SHIELD_UNLOCKED) return
    viewModelScope.launch {
      try {
        repository.logSecurityEvent(
          category = "DEEPFAKE-AUTH",
          severity = AuditSeverity.SUCCESS_YELLOW,
          title = "نجاح التحقق الحيوي — كاشف التزييف العميق",
          details = "تأكدت حيوية الوجه ثلاثية الأبعاد (Liveness 100%) وتم رفض احتمالية الصور الثابتة.",
        )
      } catch (_: Exception) {}

      sessionFlow.update {
        it.copy(
          gateState = RootGateState.PRIDE_SHIELD_UNLOCKED,
          activeTab = ShieldTab.COMMAND_CENTER,
          statusBanner =
            StatusBannerMessage(
              title = "تم التحقق الحيوي بنجاح (Liveness 100%)",
              subtitle = "درع Pride Shield 2028 نشط — الشبكة الكمية مؤمنة بالكامل.",
              isWarningRed = false,
              isSuccessYellow = true,
            ),
        )
      }
      if (sessionFlow.value.zeroTrustSummary == null) {
        triggerZeroTrustScan()
      }
    }
  }

  fun submitEmergencyPin(pinInput: String) {
    viewModelScope.launch {
      try {
        val valid = repository.verifyEmergencyPin(pinInput)
        if (valid) {
          sessionFlow.update {
            it.copy(
              gateState = RootGateState.PRIDE_SHIELD_UNLOCKED,
              activeTab = ShieldTab.COMMAND_CENTER,
              pinAuthError = "",
              statusBanner =
                StatusBannerMessage(
                  title = "تم فتح الدرع عبر رمز الطوارئ (PIN)",
                  subtitle = "تجاوز آمن لعطل الكاميرا وفق بروتوكول استمرارية الحماية.",
                  isWarningRed = false,
                  isSuccessYellow = true,
                ),
            )
          }
          if (sessionFlow.value.zeroTrustSummary == null) {
            triggerZeroTrustScan()
          }
        } else {
          sessionFlow.update {
            it.copy(pinAuthError = "رمز المرور (PIN) غير مطابق — أعد المحاولة")
          }
        }
      } catch (_: Exception) {
        sessionFlow.update { it.copy(pinAuthError = "تعذر التحقق من الرمز، حاول مجدداً") }
      }
    }
  }

  fun triggerPanicCamouflage() {
    viewModelScope.launch {
      try {
        repository.logSecurityEvent(
          category = "CAMOUFLAGE-LOCK",
          severity = AuditSeverity.INFO_BLUE,
          title = "تفعيل وضع التمويه الفوري",
          details = "تم إغلاق الجلسة وتصفير المعاينات المؤقتة والعودة لواجهة الآلة الحاسبة.",
        )
      } catch (_: Exception) {}
      sessionFlow.update {
        InternalSessionState(
          gateState = RootGateState.CAMOUFLAGE_CALCULATOR,
          zeroTrustSummary = it.zeroTrustSummary,
        )
      }
    }
  }

  fun selectTab(tab: ShieldTab) {
    sessionFlow.update { it.copy(activeTab = tab) }
    if (tab == ShieldTab.ZERO_TRUST_AI && sessionFlow.value.zeroTrustSummary == null) {
      triggerZeroTrustScan()
    }
  }

  fun dismissStatusBanner() {
    sessionFlow.update { it.copy(statusBanner = null) }
  }

  // --- Quantum AES-256 Encryption, RAM Key Destruction & Quarantine ---

  fun encryptPickedFile(uri: Uri, passphrase: String) {
    viewModelScope.launch {
      sessionFlow.update { it.copy(isCryptoBusy = true) }
      try {
        val outcome =
          repository.encryptUriIntoVault(
            uri = uri,
            passphrase = passphrase.ifBlank { SecurityPreferencesRepository.DEFAULT_EMERGENCY_PIN },
            simulateFault = false,
          )
        publishEncryptionBanner(outcome)
      } catch (e: Exception) {
        sessionFlow.update {
          it.copy(
            statusBanner =
              StatusBannerMessage(
                title = "تنبيه في هندسة الأخطاء",
                subtitle = e.localizedMessage ?: "تمت معالجة الاستثناء وحفظ الاستقرار",
                isWarningRed = true,
                isSuccessYellow = false,
              )
          )
        }
      } finally {
        sessionFlow.update { it.copy(isCryptoBusy = false) }
      }
    }
  }

  fun encryptSecretNote(
    title: String,
    content: String,
    passphrase: String,
    simulateCipherFailure: Boolean = false,
  ) {
    viewModelScope.launch {
      sessionFlow.update { it.copy(isCryptoBusy = true) }
      try {
        val safeContent =
          content.ifBlank {
            "بيانات سرية مصنفة — Pride Shield Quantum Protocol ${System.currentTimeMillis()}"
          }
        val outcome =
          repository.encryptSecretNoteIntoVault(
            title = title,
            secretContent = safeContent,
            passphrase = passphrase.ifBlank { SecurityPreferencesRepository.DEFAULT_EMERGENCY_PIN },
            simulateFault = simulateCipherFailure,
          )
        publishEncryptionBanner(outcome)
      } catch (e: Exception) {
        sessionFlow.update {
          it.copy(
            statusBanner =
              StatusBannerMessage(
                title = "تم احتواء خطأ التشفير",
                subtitle = e.localizedMessage ?: "حُفظت العملية دون انهيار",
                isWarningRed = true,
                isSuccessYellow = false,
              )
          )
        }
      } finally {
        sessionFlow.update { it.copy(isCryptoBusy = false) }
      }
    }
  }

  private fun publishEncryptionBanner(outcome: EncryptionOutcome) {
    when (outcome) {
      is EncryptionOutcome.EncryptedSuccess -> {
        sessionFlow.update {
          it.copy(
            statusBanner =
              StatusBannerMessage(
                title = "نجاح التشفير الكمي AES-256 + تدمير المفتاح من RAM!",
                subtitle =
                  "تم تصفير ${outcome.ramWipeReport.bytesZeroized} بايت من الذاكرة بـ 3 مراحل (0xFF→0xAA→0x00) خلال ${outcome.ramWipeReport.elapsedMs}ms.",
                isWarningRed = false,
                isSuccessYellow = true,
              )
          )
        }
      }
      is EncryptionOutcome.QuarantinedInSandbox -> {
        sessionFlow.update {
          it.copy(
            statusBanner =
              StatusBannerMessage(
                title = "تحذير: فشل التشفير — تم حفظ الملف في المساحة المعزولة!",
                subtitle =
                  "حُفظت بياناتك بأمان في صندوق العزل المعزول (Isolated Sandbox) وتدمير المفاتيح من RAM. السبب: ${outcome.failureReason}",
                isWarningRed = true,
                isSuccessYellow = false,
              )
          )
        }
      }
      is EncryptionOutcome.FatalFailure -> {
        sessionFlow.update {
          it.copy(
            statusBanner =
              StatusBannerMessage(
                title = "تحذير: تعذر إتمام العملية",
                subtitle = outcome.errorMessage,
                isWarningRed = true,
                isSuccessYellow = false,
              )
          )
        }
      }
    }
  }

  fun decryptAndPreviewItem(entity: VaultFileEntity, passphrase: String) {
    viewModelScope.launch {
      sessionFlow.update { it.copy(isCryptoBusy = true) }
      try {
        val outcome =
          repository.decryptVaultEntity(
            entity = entity,
            passphrase = passphrase.ifBlank { SecurityPreferencesRepository.DEFAULT_EMERGENCY_PIN },
          )
        when (outcome) {
          is DecryptionOutcome.DecryptedSuccess -> {
            // Wipe raw byte array after extracting preview string
            try {
              outcome.plaintextBytes.fill(0)
            } catch (_: Exception) {}
            sessionFlow.update {
              it.copy(
                decryptedPreview =
                  DecryptedPreviewDialogState(
                    fileName = entity.originalName,
                    previewText = outcome.previewText,
                    sha256Digest = entity.sha256Digest,
                    ramWipeReport = outcome.ramWipeReport,
                  ),
                statusBanner =
                  StatusBannerMessage(
                    title = "فك تشفير آمن + تصفير مفتاح الجلسة من RAM",
                    subtitle =
                      "تم تدمير ${outcome.ramWipeReport.bytesZeroized} بايت من مفتاح AES-256 فور استخراج المحتوى.",
                    isWarningRed = false,
                    isSuccessYellow = true,
                  ),
              )
            }
          }
          is DecryptionOutcome.DecryptionFailed -> {
            sessionFlow.update {
              it.copy(
                statusBanner =
                  StatusBannerMessage(
                    title = "فشل فك التشفير — مفتاح غير مطابق",
                    subtitle = outcome.errorMessage,
                    isWarningRed = true,
                    isSuccessYellow = false,
                  )
              )
            }
          }
        }
      } finally {
        sessionFlow.update { it.copy(isCryptoBusy = false) }
      }
    }
  }

  fun closeDecryptedPreview() {
    sessionFlow.update { it.copy(decryptedPreview = null) }
  }

  fun retryQuarantinedItem(entity: VaultFileEntity, passphrase: String) {
    viewModelScope.launch {
      sessionFlow.update { it.copy(isCryptoBusy = true) }
      try {
        val recovered =
          repository.retryQuarantineEncryption(
            entity = entity,
            passphrase = passphrase.ifBlank { SecurityPreferencesRepository.DEFAULT_EMERGENCY_PIN },
          )
        sessionFlow.update {
          it.copy(
            statusBanner =
              if (recovered) {
                StatusBannerMessage(
                  title = "نجحت استعادة الملف من المساحة المعزولة وتشفيره!",
                  subtitle = "تم تشفير (${entity.originalName}) بمعيار AES-256 وتدمير المفتاح في RAM.",
                  isWarningRed = false,
                  isSuccessYellow = true,
                )
              } else {
                StatusBannerMessage(
                  title = "استمر بقاء الملف في المساحة المعزولة",
                  subtitle = "تعذرت إعادة التشفير حالياً؛ الملف لا يزال محفوظاً بأمان داخل العزل.",
                  isWarningRed = true,
                  isSuccessYellow = false,
                )
              }
          )
        }
      } finally {
        sessionFlow.update { it.copy(isCryptoBusy = false) }
      }
    }
  }

  fun shredVaultEntity(entity: VaultFileEntity) {
    viewModelScope.launch {
      repository.shredVaultItem(entity)
      sessionFlow.update {
        it.copy(
          statusBanner =
            StatusBannerMessage(
              title = "تم الإتلاف النهائي للملف",
              subtitle = "كُتبت أصفار فوق قطاعات الملف (${entity.originalName}) وحُذف نهائياً.",
              isWarningRed = false,
              isSuccessYellow = true,
            )
        )
      }
    }
  }

  // --- Zero-Trust AI Behavioral Scanner ---

  fun triggerZeroTrustScan() {
    if (sessionFlow.value.isScanningZeroTrust) return
    viewModelScope.launch {
      sessionFlow.update { it.copy(isScanningZeroTrust = true) }
      try {
        val summary = repository.runZeroTrustScan()
        sessionFlow.update { it.copy(zeroTrustSummary = summary) }
      } finally {
        sessionFlow.update { it.copy(isScanningZeroTrust = false) }
      }
    }
  }

  fun toggleWatchlist(report: AppBehaviorReport, isCurrentlyWatched: Boolean) {
    viewModelScope.launch { repository.togglePackageWatchlist(report, isCurrentlyWatched) }
  }

  // --- Camouflage & Security Settings ---

  fun saveSecurityCodes(newCalcCode: String, newEmergencyPin: String) {
    viewModelScope.launch {
      val ok = repository.updateCodes(newCalcCode, newEmergencyPin)
      sessionFlow.update {
        it.copy(
          statusBanner =
            if (ok) {
              StatusBannerMessage(
                title = "تم تحديث كود التمويه ورمز الطوارئ بنجاح",
                subtitle = "تم حفظ التجزئة المشفرة SHA-256 للأكواد الجديدة.",
                isWarningRed = false,
                isSuccessYellow = true,
              )
            } else {
              StatusBannerMessage(
                title = "تنبيه: يجب ألا يقل الكود عن 4 أرقام",
                subtitle = "يرجى إدخال 4 أرقام على الأقل لكل من كود الحاسبة ورمز PIN.",
                isWarningRed = true,
                isSuccessYellow = false,
              )
            }
        )
      }
    }
  }

  fun togglePureStealthMode(enabled: Boolean) {
    viewModelScope.launch { repository.setPureStealthMode(enabled) }
  }

  fun clearAuditLogs() {
    viewModelScope.launch { repository.clearAuditHistory() }
  }

  private fun appendCalculatorSymbol(current: String, symbol: String): String {
    val operators = setOf("+", "−", "×", "÷", "%")
    if (symbol in operators) {
      if (current.isEmpty()) return if (symbol == "−") "−" else ""
      val lastStr = current.last().toString()
      if (lastStr in setOf("+", "−", "×", "÷")) {
        return current.dropLast(1) + symbol
      }
    }
    if (symbol == ".") {
      val lastNumberSegment = current.split('+', '−', '×', '÷', '%').lastOrNull().orEmpty()
      if (lastNumberSegment.contains(".")) return current
      if (lastNumberSegment.isEmpty()) return "${current}0."
    }
    return current + symbol
  }

  private fun toggleSign(current: String): String {
    if (current.isEmpty()) return "-"
    return if (current.startsWith("-")) current.removePrefix("-") else "-$current"
  }
}
