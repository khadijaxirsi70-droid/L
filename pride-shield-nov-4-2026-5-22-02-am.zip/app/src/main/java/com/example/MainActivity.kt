package com.example

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ui.PrideShieldApp
import com.example.ui.theme.PrideShieldTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    try {
      enableEdgeToEdge()
    } catch (_: Exception) {
      // Resilient fallback if edge-to-edge fails on custom OEM window managers
    }

    // Note: Keep screenshots visible in streaming emulator preview while hardening surface handling
    try {
      window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    } catch (_: Exception) {}

    setContent {
      PrideShieldTheme {
        PrideShieldApp()
      }
    }
  }
}
