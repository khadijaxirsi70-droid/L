package com.example.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.local.AuditSeverity
import com.example.data.local.PrideShieldDao
import com.example.data.local.SecurityAuditEntity
import com.example.data.local.VaultFileEntity
import com.example.data.local.ZeroTrustWatchEntity
import com.example.data.preferences.SecurityPreferencesRepository
import com.example.data.preferences.SecurityPreferencesState
import com.example.security.AppBehaviorReport
import com.example.security.DecryptionOutcome
import com.example.security.EncryptionOutcome
import com.example.security.QuantumVaultCryptoEngine
import com.example.security.ZeroTrustBehavioralEngine
import com.example.security.ZeroTrustScanSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.withContext

class PrideShieldRepository(
  private val appContext: Context,
  private val dao: PrideShieldDao,
  private val preferencesRepository: SecurityPreferencesRepository,
  private val cryptoEngine: QuantumVaultCryptoEngine,
  private val zeroTrustEngine: ZeroTrustBehavioralEngine,
) {

  val vaultFilesFlow: Flow<List<VaultFileEntity>> =
    dao.observeAllVaultFiles().catch { emit(emptyList()) }

  val securityAuditsFlow: Flow<List<SecurityAuditEntity>> =
    dao.observeSecurityAudits().catch { emit(emptyList()) }

  val watchlistFlow: Flow<List<ZeroTrustWatchEntity>> =
    dao.observeWatchlist().catch { emit(emptyList()) }

  val preferencesFlow: Flow<SecurityPreferencesState> = preferencesRepository.preferencesFlow

  suspend fun logSecurityEvent(
    category: String,
    severity: AuditSeverity,
    title: String,
    details: String,
  ) {
    try {
      dao.insertAudit(
        SecurityAuditEntity(
          category = category,
          severity = severity.name,
          title = title,
          details = details,
        )
      )
    } catch (_: Exception) {
      // Never propagate logging failure
    }
  }

  suspend fun verifyCalculatorSecretCode(input: String): Boolean {
    return try {
      preferencesRepository.verifyCalculatorSecretCode(input)
    } catch (_: Exception) {
      false
    }
  }

  suspend fun verifyEmergencyPin(pin: String): Boolean {
    return try {
      val valid = preferencesRepository.verifyEmergencyPin(pin)
      if (valid) {
        logSecurityEvent(
          category = "AUTH-PIN",
          severity = AuditSeverity.SUCCESS_YELLOW,
          title = "فتح الدرع عبر رمز الطوارئ (PIN)",
          details = "تم التحقق المشفر SHA-256 من رمز المرور بنجاح بعد تفعيل بروتوكول الطوارئ.",
        )
      } else {
        logSecurityEvent(
          category = "AUTH-PIN",
          severity = AuditSeverity.WARNING_RED,
          title = "محاولة إدخال رمز PIN خاطئ",
          details = "تم رفض الوصول وتسجيل الحدث في سجل الرصد الأمني.",
        )
      }
      valid
    } catch (_: Exception) {
      false
    }
  }

  suspend fun encryptUriIntoVault(
    uri: Uri,
    passphrase: String,
    simulateFault: Boolean = false,
  ): EncryptionOutcome =
    withContext(Dispatchers.IO) {
      var rawBytes = ByteArray(0)
      var resolvedName = "encrypted_document.bin"
      var mimeType = "application/octet-stream"

      try {
        mimeType = appContext.contentResolver.getType(uri) ?: "application/octet-stream"
        resolvedName = queryFileName(uri) ?: "asset_${System.currentTimeMillis()}.bin"

        rawBytes =
          appContext.contentResolver.openInputStream(uri)?.use { stream ->
            // Cap in-memory read to 12 MB for safe RAM handling
            val maxBytes = 12 * 1024 * 1024
            val buffer = stream.readBytes()
            if (buffer.size > maxBytes) buffer.copyOf(maxBytes) else buffer
          } ?: throw IllegalStateException("تعذر فتح دفق قراءة الملف من النظام")

        processPayloadEncryption(
          fileName = resolvedName,
          mimeType = mimeType,
          rawBytes = rawBytes,
          passphrase = passphrase,
          isTextNote = false,
          simulateFault = simulateFault,
        )
      } catch (e: Exception) {
        // Even if URI stream fails mid-way, quarantine whatever bytes were recovered or log isolation
        val fallbackOutcome =
          cryptoEngine.encryptAndWipeKey(
            fileName = resolvedName,
            rawPayload =
              if (rawBytes.isNotEmpty()) rawBytes
              else "STREAM_RECOVERY_MARKER::$resolvedName".toByteArray(Charsets.UTF_8),
            passphraseChars = passphrase.toCharArray(),
            simulateCipherFault = true,
          )
        recordEncryptionOutcomeInDb(
          fileName = resolvedName,
          mimeType = mimeType,
          isTextNote = false,
          outcome = fallbackOutcome,
          overrideReason = e.localizedMessage,
        )
        fallbackOutcome
      } finally {
        try {
          rawBytes.fill(0)
        } catch (_: Exception) {}
      }
    }

  suspend fun encryptSecretNoteIntoVault(
    title: String,
    secretContent: String,
    passphrase: String,
    simulateFault: Boolean = false,
  ): EncryptionOutcome =
    withContext(Dispatchers.IO) {
      val cleanTitle = title.trim().ifBlank { "وثيقة_سرية_${System.currentTimeMillis() % 10000}.txt" }
      val finalName = if (cleanTitle.contains(".")) cleanTitle else "$cleanTitle.txt"
      val rawBytes = secretContent.toByteArray(Charsets.UTF_8)
      try {
        processPayloadEncryption(
          fileName = finalName,
          mimeType = "text/plain",
          rawBytes = rawBytes,
          passphrase = passphrase,
          isTextNote = true,
          simulateFault = simulateFault,
        )
      } finally {
        try {
          rawBytes.fill(0)
        } catch (_: Exception) {}
      }
    }

  private suspend fun processPayloadEncryption(
    fileName: String,
    mimeType: String,
    rawBytes: ByteArray,
    passphrase: String,
    isTextNote: Boolean,
    simulateFault: Boolean,
  ): EncryptionOutcome {
    val passChars = passphrase.toCharArray()
    val outcome =
      cryptoEngine.encryptAndWipeKey(
        fileName = fileName,
        rawPayload = rawBytes,
        passphraseChars = passChars,
        simulateCipherFault = simulateFault,
      )
    recordEncryptionOutcomeInDb(
      fileName = fileName,
      mimeType = mimeType,
      isTextNote = isTextNote,
      outcome = outcome,
      overrideReason = null,
    )
    return outcome
  }

  private suspend fun recordEncryptionOutcomeInDb(
    fileName: String,
    mimeType: String,
    isTextNote: Boolean,
    outcome: EncryptionOutcome,
    overrideReason: String?,
  ) {
    try {
      when (outcome) {
        is EncryptionOutcome.EncryptedSuccess -> {
          preferencesRepository.recordRamBytesWiped(outcome.ramWipeReport.bytesZeroized)
          dao.insertVaultFile(
            VaultFileEntity(
              originalName = fileName,
              mimeType = mimeType,
              storedFilePath = outcome.storedPath,
              sizeBytes = outcome.cipherSizeBytes,
              sha256Digest = outcome.sha256Digest,
              ivHex = outcome.ivHex,
              saltHex = outcome.saltHex,
              isEncrypted = true,
              isQuarantined = false,
              ramBytesZeroized = outcome.ramWipeReport.bytesZeroized,
              isTextNote = isTextNote,
            )
          )
          logSecurityEvent(
            category = "QUANTUM-AES256",
            severity = AuditSeverity.SUCCESS_YELLOW,
            title = "تشفير AES-256 وتدمير المفتاح في RAM: $fileName",
            details =
              "تم التشفير بنجاح وتصفير ${outcome.ramWipeReport.bytesZeroized} بايت من الذاكرة (3 مراحل) خلال ${outcome.ramWipeReport.elapsedMs}ms — بصمة المفتاح المدمر: ${outcome.ramWipeReport.keyFingerprintBeforeWipe}",
          )
        }
        is EncryptionOutcome.QuarantinedInSandbox -> {
          preferencesRepository.recordRamBytesWiped(outcome.ramWipeReport.bytesZeroized)
          val reason = overrideReason ?: outcome.failureReason
          dao.insertVaultFile(
            VaultFileEntity(
              originalName = fileName,
              mimeType = mimeType,
              storedFilePath = outcome.isolatedPath,
              sizeBytes = outcome.rawSizeBytes,
              sha256Digest = outcome.sha256Digest,
              ivHex = "",
              saltHex = "",
              isEncrypted = false,
              isQuarantined = true,
              quarantineReason = reason,
              ramBytesZeroized = outcome.ramWipeReport.bytesZeroized,
              isTextNote = isTextNote,
            )
          )
          logSecurityEvent(
            category = "QUARANTINE-SANDBOX",
            severity = AuditSeverity.WARNING_RED,
            title = "فشل التشفير — تم حفظ الملف في المساحة المعزولة!",
            details =
              "الملف ($fileName) حُفظ بأمان داخل صندوق العزل الخاص (MODE_PRIVATE) لمنع الفقدان. السبب: $reason",
          )
        }
        is EncryptionOutcome.FatalFailure -> {
          logSecurityEvent(
            category = "CRYPTO-ERROR",
            severity = AuditSeverity.WARNING_RED,
            title = "خطأ حرج في محرك التشفير",
            details = outcome.errorMessage,
          )
        }
      }
    } catch (_: Exception) {}
  }

  suspend fun decryptVaultEntity(entity: VaultFileEntity, passphrase: String): DecryptionOutcome {
    return try {
      val passChars = passphrase.toCharArray()
      val outcome =
        cryptoEngine.decryptVaultFile(
          storedPath = entity.storedFilePath,
          ivHex = entity.ivHex,
          saltHex = entity.saltHex,
          mimeType = entity.mimeType,
          passphraseChars = passChars,
        )
      when (outcome) {
        is DecryptionOutcome.DecryptedSuccess -> {
          preferencesRepository.recordRamBytesWiped(outcome.ramWipeReport.bytesZeroized)
          logSecurityEvent(
            category = "QUANTUM-DECRYPT",
            severity = AuditSeverity.SUCCESS_YELLOW,
            title = "فك تشفير آمن وتصفير RAM: ${entity.originalName}",
            details =
              "تم التحقق من ختم المصادقة GCM وتدمير المفتاح المشتق (${outcome.ramWipeReport.bytesZeroized} بايت) فوراً.",
          )
        }
        is DecryptionOutcome.DecryptionFailed -> {
          preferencesRepository.recordRamBytesWiped(outcome.ramWipeReport.bytesZeroized)
          logSecurityEvent(
            category = "QUANTUM-DECRYPT",
            severity = AuditSeverity.WARNING_RED,
            title = "رفض فك التشفير: ${entity.originalName}",
            details = outcome.errorMessage,
          )
        }
      }
      outcome
    } catch (e: Exception) {
      DecryptionOutcome.DecryptionFailed(
        errorMessage = e.localizedMessage ?: "خطأ غير متوقع أثناء فك التشفير",
        ramWipeReport =
          com.example.security.RamWipeReport(
            bytesZeroized = 32,
            passesCompleted = 3,
            keyFingerprintBeforeWipe = "ERR",
            elapsedMs = 1L,
          ),
      )
    }
  }

  suspend fun retryQuarantineEncryption(entity: VaultFileEntity, passphrase: String): Boolean {
    return try {
      if (!entity.isQuarantined) return false
      val outcome =
        cryptoEngine.retryEncryptFromQuarantine(
          quarantinePath = entity.storedFilePath,
          originalName = entity.originalName,
          passphraseChars = passphrase.toCharArray(),
        )
      if (outcome is EncryptionOutcome.EncryptedSuccess) {
        preferencesRepository.recordRamBytesWiped(outcome.ramWipeReport.bytesZeroized)
        dao.updateVaultFile(
          entity.copy(
            storedFilePath = outcome.storedPath,
            sizeBytes = outcome.cipherSizeBytes,
            sha256Digest = outcome.sha256Digest,
            ivHex = outcome.ivHex,
            saltHex = outcome.saltHex,
            isEncrypted = true,
            isQuarantined = false,
            quarantineReason = "",
            ramBytesZeroized = outcome.ramWipeReport.bytesZeroized,
          )
        )
        logSecurityEvent(
          category = "QUARANTINE-RECOVERY",
          severity = AuditSeverity.SUCCESS_YELLOW,
          title = "استعادة وتشفير ملف معزول بنجاح: ${entity.originalName}",
          details = "نُقل الملف من المساحة المعزولة إلى خزنة AES-256 وتم تدمير المفتاح المؤقت في RAM.",
        )
        true
      } else {
        false
      }
    } catch (_: Exception) {
      false
    }
  }

  suspend fun shredVaultItem(entity: VaultFileEntity) {
    try {
      cryptoEngine.shredStoredFile(entity.storedFilePath)
      dao.deleteVaultFileById(entity.id)
      logSecurityEvent(
        category = "SHREDDER",
        severity = AuditSeverity.INFO_BLUE,
        title = "إتلاف نهائي للملف: ${entity.originalName}",
        details = "تمت الكتابة الصفرية فوق الملف وحذفه من السجل المحلي.",
      )
    } catch (_: Exception) {}
  }

  suspend fun runZeroTrustScan(): ZeroTrustScanSummary {
    return try {
      val summary = zeroTrustEngine.performDeepBehavioralScan()
      val severity =
        if (summary.criticalCount > 0) AuditSeverity.WARNING_RED else AuditSeverity.SUCCESS_YELLOW
      logSecurityEvent(
        category = "ZERO-TRUST-AI",
        severity = severity,
        title = "اكتمال الفحص السلوكي للثقة الصفرية (${summary.overallTrustIndex}%)",
        details =
          "تم فحص ${summary.appReports.size} حزمة: ${summary.criticalCount} عالية الخطورة، ${summary.elevatedCount} قيد الرصد، ${summary.trustedCount} موثوقة.",
      )
      summary
    } catch (e: Exception) {
      logSecurityEvent(
        category = "ZERO-TRUST-AI",
        severity = AuditSeverity.WARNING_RED,
        title = "تنبيه في محرك الثقة الصفرية",
        details = e.localizedMessage ?: "تم استخدام وضع الفحص الاحتياطي المعزول",
      )
      ZeroTrustScanSummary(
        overallTrustIndex = 85,
        osSignals = emptyList(),
        appReports = emptyList(),
        criticalCount = 0,
        elevatedCount = 0,
        trustedCount = 0,
      )
    }
  }

  suspend fun togglePackageWatchlist(report: AppBehaviorReport, currentlyWatched: Boolean) {
    try {
      if (currentlyWatched) {
        dao.removeWatchItem(report.packageName)
        logSecurityEvent(
          category = "ZERO-TRUST-AI",
          severity = AuditSeverity.INFO_BLUE,
          title = "رفع العزل الرقابي: ${report.appName}",
          details = "أزيلت الحزمة (${report.packageName}) من قائمة المراقبة الصفرية.",
        )
      } else {
        dao.upsertWatchItem(
          ZeroTrustWatchEntity(
            packageName = report.packageName,
            appLabel = report.appName,
            riskScore = report.riskScore,
            flaggedVectors = report.behaviorSummary,
          )
        )
        logSecurityEvent(
          category = "ZERO-TRUST-AI",
          severity = AuditSeverity.WARNING_RED,
          title = "عزل رقابي لحزمة مشبوهة: ${report.appName}",
          details = "أضيفت (${report.packageName}) لقائمة الحصار الصفري بدرجة خطورة ${report.riskScore}/100.",
        )
      }
    } catch (_: Exception) {}
  }

  suspend fun updateCodes(calcSecret: String, emergencyPin: String): Boolean {
    val updated = preferencesRepository.updateSecurityCodes(calcSecret, emergencyPin)
    if (updated) {
      logSecurityEvent(
        category = "CAMOUFLAGE-CONFIG",
        severity = AuditSeverity.SUCCESS_YELLOW,
        title = "تحديث كود التمويه السري ورمز الطوارئ PIN",
        details = "تم تجزئة الأكواد الجديدة بخوارزمية SHA-256 المملحة وتصفير النص الخام من الذاكرة.",
      )
    }
    return updated
  }

  suspend fun setPureStealthMode(enabled: Boolean) {
    preferencesRepository.setPureStealthMode(enabled)
  }

  suspend fun dismissCalculatorOnboardingHint() {
    preferencesRepository.dismissOnboardingHint()
  }

  suspend fun clearAuditHistory() {
    try {
      dao.clearAllAudits()
    } catch (_: Exception) {}
  }

  private fun queryFileName(uri: Uri): String? {
    return try {
      appContext.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (nameIndex >= 0 && cursor.moveToFirst()) {
          cursor.getString(nameIndex)
        } else {
          null
        }
      }
    } catch (_: Exception) {
      uri.lastPathSegment
    }
  }
}
