package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AuditSeverity {
  SUCCESS_YELLOW,
  INFO_BLUE,
  WARNING_RED,
}

@Entity(tableName = "vault_files")
data class VaultFileEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val originalName: String,
  val mimeType: String,
  val storedFilePath: String,
  val sizeBytes: Long,
  val sha256Digest: String,
  val ivHex: String,
  val saltHex: String,
  val isEncrypted: Boolean,
  val isQuarantined: Boolean,
  val quarantineReason: String = "",
  val ramBytesZeroized: Int = 0,
  val isTextNote: Boolean = false,
  val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "security_audits")
data class SecurityAuditEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val category: String,
  val severity: String, // AuditSeverity.name
  val title: String,
  val details: String,
  val timestamp: Long = System.currentTimeMillis(),
)

@Entity(tableName = "zerotrust_watchlist")
data class ZeroTrustWatchEntity(
  @PrimaryKey val packageName: String,
  val appLabel: String,
  val riskScore: Int,
  val flaggedVectors: String,
  val isolatedAt: Long = System.currentTimeMillis(),
)
