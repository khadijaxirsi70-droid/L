package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [VaultFileEntity::class, SecurityAuditEntity::class, ZeroTrustWatchEntity::class],
  version = 1,
  exportSchema = false,
)
abstract class PrideShieldDatabase : RoomDatabase() {
  abstract fun prideShieldDao(): PrideShieldDao

  companion object {
    @Volatile private var instance: PrideShieldDatabase? = null

    fun getInstance(context: Context): PrideShieldDatabase {
      return instance
        ?: synchronized(this) {
          instance
            ?: try {
              Room.databaseBuilder(
                  context.applicationContext,
                  PrideShieldDatabase::class.java,
                  "pride_shield_2028.db",
                )
                .fallbackToDestructiveMigration(dropAllTables = true)
                .build()
                .also { instance = it }
            } catch (_: Exception) {
              // Resilient in-memory fallback if disk database initialization fails
              Room.inMemoryDatabaseBuilder(
                  context.applicationContext,
                  PrideShieldDatabase::class.java,
                )
                .build()
                .also { instance = it }
            }
        }
    }
  }
}
