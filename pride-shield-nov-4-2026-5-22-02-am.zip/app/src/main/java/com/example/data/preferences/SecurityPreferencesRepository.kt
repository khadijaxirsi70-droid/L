package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.security.MessageDigest
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.securityDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "pride_shield_security_prefs")

data class SecurityPreferencesState(
  val secretCalcCodeHash: String,
  val emergencyPinHash: String,
  val isDefaultCodeActive: Boolean,
  val pureStealthMode: Boolean,
  val onboardingHintDismissed: Boolean,
  val totalRamBytesWiped: Long,
)

class SecurityPreferencesRepository(private val context: Context) {

  companion object {
    private const val STATIC_DOMAIN_SALT = "PRIDE_SHIELD_2028_QUANTUM_SALT_V1::"
    const val DEFAULT_SECRET_CODE = "2028"
    const val DEFAULT_EMERGENCY_PIN = "2028"

    private val KEY_SECRET_CODE_HASH = stringPreferencesKey("secret_calc_code_hash")
    private val KEY_EMERGENCY_PIN_HASH = stringPreferencesKey("emergency_pin_hash")
    private val KEY_IS_DEFAULT_CODE = booleanPreferencesKey("is_default_code_active")
    private val KEY_PURE_STEALTH = booleanPreferencesKey("pure_stealth_mode")
    private val KEY_HINT_DISMISSED = booleanPreferencesKey("onboarding_hint_dismissed")
    private val KEY_TOTAL_RAM_WIPED = longPreferencesKey("total_ram_bytes_wiped")

    fun sha256Salted(rawInput: String): String {
      return try {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = (STATIC_DOMAIN_SALT + rawInput.trim()).toByteArray(Charsets.UTF_8)
        val hashed = digest.digest(bytes)
        // Zeroize intermediate UTF-8 input bytes
        bytes.fill(0)
        hashed.joinToString("") { "%02x".format(it) }
      } catch (_: Exception) {
        rawInput.trim().hashCode().toString(16)
      }
    }
  }

  private val defaultCodeHash = sha256Salted(DEFAULT_SECRET_CODE)
  private val defaultPinHash = sha256Salted(DEFAULT_EMERGENCY_PIN)

  val preferencesFlow: Flow<SecurityPreferencesState> =
    context.securityDataStore.data
      .catch { emit(emptyPreferences()) }
      .map { prefs ->
        SecurityPreferencesState(
          secretCalcCodeHash = prefs[KEY_SECRET_CODE_HASH] ?: defaultCodeHash,
          emergencyPinHash = prefs[KEY_EMERGENCY_PIN_HASH] ?: defaultPinHash,
          isDefaultCodeActive = prefs[KEY_IS_DEFAULT_CODE] ?: true,
          pureStealthMode = prefs[KEY_PURE_STEALTH] ?: false,
          onboardingHintDismissed = prefs[KEY_HINT_DISMISSED] ?: false,
          totalRamBytesWiped = prefs[KEY_TOTAL_RAM_WIPED] ?: 0L,
        )
      }

  suspend fun verifyCalculatorSecretCode(candidate: String): Boolean {
    return try {
      val state = preferencesFlow.first()
      sha256Salted(candidate) == state.secretCalcCodeHash
    } catch (_: Exception) {
      candidate.trim() == DEFAULT_SECRET_CODE
    }
  }

  suspend fun verifyEmergencyPin(candidate: String): Boolean {
    return try {
      val state = preferencesFlow.first()
      sha256Salted(candidate) == state.emergencyPinHash
    } catch (_: Exception) {
      candidate.trim() == DEFAULT_EMERGENCY_PIN
    }
  }

  suspend fun updateSecurityCodes(newCalcCode: String, newEmergencyPin: String): Boolean {
    return try {
      val cleanCalc = newCalcCode.trim()
      val cleanPin = newEmergencyPin.trim()
      if (cleanCalc.length < 4 || cleanPin.length < 4) return false
      context.securityDataStore.edit { prefs ->
        prefs[KEY_SECRET_CODE_HASH] = sha256Salted(cleanCalc)
        prefs[KEY_EMERGENCY_PIN_HASH] = sha256Salted(cleanPin)
        prefs[KEY_IS_DEFAULT_CODE] =
          (cleanCalc == DEFAULT_SECRET_CODE && cleanPin == DEFAULT_EMERGENCY_PIN)
      }
      true
    } catch (_: Exception) {
      false
    }
  }

  suspend fun setPureStealthMode(enabled: Boolean) {
    try {
      context.securityDataStore.edit { prefs -> prefs[KEY_PURE_STEALTH] = enabled }
    } catch (_: Exception) {
      // Safe fallback
    }
  }

  suspend fun dismissOnboardingHint() {
    try {
      context.securityDataStore.edit { prefs -> prefs[KEY_HINT_DISMISSED] = true }
    } catch (_: Exception) {
      // Safe fallback
    }
  }

  suspend fun recordRamBytesWiped(bytesWiped: Int) {
    if (bytesWiped <= 0) return
    try {
      context.securityDataStore.edit { prefs ->
        val current = prefs[KEY_TOTAL_RAM_WIPED] ?: 0L
        prefs[KEY_TOTAL_RAM_WIPED] = current + bytesWiped.toLong()
      }
    } catch (_: Exception) {
      // Safe fallback
    }
  }
}
