package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PrideShieldDao {
  @Query("SELECT * FROM vault_files ORDER BY createdAt DESC")
  fun observeAllVaultFiles(): Flow<List<VaultFileEntity>>

  @Query("SELECT * FROM vault_files WHERE id = :id LIMIT 1")
  suspend fun getVaultFileById(id: Long): VaultFileEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertVaultFile(entity: VaultFileEntity): Long

  @Update
  suspend fun updateVaultFile(entity: VaultFileEntity)

  @Query("DELETE FROM vault_files WHERE id = :id")
  suspend fun deleteVaultFileById(id: Long)

  @Query("SELECT * FROM security_audits ORDER BY timestamp DESC LIMIT 120")
  fun observeSecurityAudits(): Flow<List<SecurityAuditEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAudit(audit: SecurityAuditEntity)

  @Query("DELETE FROM security_audits")
  suspend fun clearAllAudits()

  @Query("SELECT * FROM zerotrust_watchlist ORDER BY isolatedAt DESC")
  fun observeWatchlist(): Flow<List<ZeroTrustWatchEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertWatchItem(item: ZeroTrustWatchEntity)

  @Query("DELETE FROM zerotrust_watchlist WHERE packageName = :packageName")
  suspend fun removeWatchItem(packageName: String)
}
